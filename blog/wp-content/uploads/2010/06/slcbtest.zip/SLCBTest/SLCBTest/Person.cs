﻿using System;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.ComponentModel;

namespace SLCBTest
{
    public class Person : INotifyPropertyChanged
    {
        private string _name;
        private ObservableCollection<PhoneNumber> _phoneNumbers = new ObservableCollection<PhoneNumber>();
        private PhoneNumber _preferredPhone;
        private ColorSelection _favoriteColor;

        public Person(string name)
        {
            _name = name;
        }

        public string Name
        {
            get { return _name; }
        }

        public string Display
        {
            get
            {
                return string.Format("{0} ({1})", _name, _preferredPhone);
            }
        }

        public ObservableCollection<PhoneNumber> PhoneNumbers
        {
            get { return _phoneNumbers; }
        }

        public PhoneNumber PreferredPhone
        {
            get { return _preferredPhone; }
            set { _preferredPhone = value; RaisePropertyChanged("PreferredPhone"); RaisePropertyChanged("Display"); }
        }

        public IEnumerable<ColorSelection> AllColors
        {
            get
            {
                yield return ColorSelection.Red;
                yield return ColorSelection.Green;
                yield return ColorSelection.Blue;
                yield return ColorSelection.Yellow;
            }
        }

        public ColorSelection FavoriteColor
        {
            get { return _favoriteColor; }
            set { _favoriteColor = value; RaisePropertyChanged("FavoriteColor"); }
        }

        public override string ToString()
        {
            return _name;
        }

        private void RaisePropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
