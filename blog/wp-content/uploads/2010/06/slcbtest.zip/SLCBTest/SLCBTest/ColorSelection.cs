using System;

namespace SLCBTest
{
    public enum ColorSelection
    {
        Red,
        Green,
        Blue,
        Yellow
    }
}
