using System;

namespace WPFCBTest
{
    public class PhoneNumber
    {
        private string _number;

        public string Number
        {
            get { return _number; }
            set { _number = value; }
        }

        public override string ToString()
        {
            return _number;
        }

        public override bool Equals(object obj)
        {
            if (obj == this)
                return true;
            PhoneNumber that = obj as PhoneNumber;
            if (that == null)
                return false;
            return this._number.Equals(that._number);
        }

        public override int GetHashCode()
        {
            return _number.GetHashCode();
        }
    }
}
