using System;
using System.Collections.ObjectModel;

namespace WPFCBTest
{
    public class PersonList
    {
        private ObservableCollection<Person> _people = new ObservableCollection<Person>();

        public PersonList()
        {
            // Populate with sample data.
            Person michael = new Person("Michael");
            PhoneNumber michaelCell = new PhoneNumber() { Number = "111 111-1111" };
            michael.PhoneNumbers.Add(michaelCell);
            michael.PhoneNumbers.Add(new PhoneNumber() { Number = "222 222-2222" });
            michael.PreferredPhone = michaelCell;
            michael.FavoriteColor = ColorSelection.Green;
            _people.Add(michael);

            Person jenny = new Person("Jenny");
            jenny.PhoneNumbers.Add(new PhoneNumber() { Number = "333 333-3333" });
            jenny.PhoneNumbers.Add(new PhoneNumber() { Number = "444 444-4444" });
            PhoneNumber jennyHome = new PhoneNumber() { Number = "555 555-5555" };
            jenny.PhoneNumbers.Add(jennyHome);
            jenny.PreferredPhone = jennyHome;
            jenny.FavoriteColor = ColorSelection.Red;
            _people.Add(jenny);

            Person kaela = new Person("Kaela");
            kaela.PhoneNumbers.Add(new PhoneNumber() { Number = "666 666-6666" });
            PhoneNumber kaelaPhone = new PhoneNumber() { Number = "777 777-7777" };
            kaela.PhoneNumbers.Add(kaelaPhone);
            kaela.PreferredPhone = kaelaPhone;
            kaela.FavoriteColor = ColorSelection.Blue;
            _people.Add(kaela);
        }

        public ObservableCollection<Person> People
        {
            get { return _people; }
        }
    }
}
