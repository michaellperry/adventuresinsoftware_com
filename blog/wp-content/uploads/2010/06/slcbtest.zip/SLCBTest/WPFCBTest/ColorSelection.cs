using System;

namespace WPFCBTest
{
    public enum ColorSelection
    {
        Red,
        Green,
        Blue,
        Yellow
    }
}
