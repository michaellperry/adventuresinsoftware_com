using System;

namespace Step3.Model
{
    public enum DisplayStrategy
    {
        LastFirst,
        FirstLast,
        Email
    }
}
