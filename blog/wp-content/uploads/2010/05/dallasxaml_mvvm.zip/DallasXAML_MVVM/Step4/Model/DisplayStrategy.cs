using System;

namespace Step4.Model
{
    public enum DisplayStrategy
    {
        LastFirst,
        FirstLast,
        Email
    }
}
