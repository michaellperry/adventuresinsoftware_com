using System;

namespace Step7.Model
{
    public enum DisplayStrategy
    {
        LastFirst,
        FirstLast,
        Email
    }
}
