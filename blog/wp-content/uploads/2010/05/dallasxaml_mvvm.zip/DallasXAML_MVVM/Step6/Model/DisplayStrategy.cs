using System;

namespace Step6.Model
{
    public enum DisplayStrategy
    {
        LastFirst,
        FirstLast,
        Email
    }
}
