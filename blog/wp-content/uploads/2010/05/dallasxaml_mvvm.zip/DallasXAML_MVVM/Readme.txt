MVVM demo for Dallas XAML

Michael L Perry
http://adventuresinsoftware.com/blog

http://twitter.com/michaellperry
mperry@mallardsoft.com
http://updatecontrols.net