﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BYORulesEngine.Rules;
using BYORulesEngine.Conditions;
using BYORulesEngine.Model;
using Predassert;

namespace BYORulesEngine.UnitTest
{
    [TestClass]
    public class IndependentRulesTest : RuleEngineTest
    {
        public TestContext TestContext { get; set; }

        [TestInitialize]
        public void Initialize()
        {
            InitializeService(
                new List<IDiscountRule>(),
                new List<IFreeItemsRule>() { new BuyOneGetOneRule(5, BurgerId, 2, IceCreamId) },
                new List<ICouponRule>() { new TriggerItemCouponRule(1, IceCreamId, "Half off") }
            );
        }

        [TestMethod]
        public void GetFreeIceCreamForBurgers()
        {
            // Buy five burgers.
            Check check = new Check();
            check.AddItem(BurgerId).Quantity = 5;
            Check outputCheck = _service.ExecuteRules(check);

            // Get two free ice creams.
            Pred.Assert(outputCheck.Items, Contains<Item>.That(
                Has<Item>.Property(item => item.ItemId, Is.EqualTo(IceCreamId))
                .And(Has<Item>.Property(item => item.UnitPrice, Is.EqualTo(0.00m)))
                .And(Has<Item>.Property(item => item.Quantity, Is.EqualTo(2)))
            ));
        }

        [TestMethod]
        public void DontAwardACouponForFreeIceCream()
        {
            // Buy five burgers.
            Check check = new Check();
            check.AddItem(BurgerId).Quantity = 5;
            Check outputCheck = _service.ExecuteRules(check);

            // No coupons awarded.
            Pred.Assert(outputCheck.Coupons, Is.Empty<Coupon>());
        }
    }
}
