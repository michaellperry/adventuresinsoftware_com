﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BYORulesEngine.Model;
using BYORulesEngine.Service;
using BYORulesEngine.Conditions;
using BYORulesEngine.Rules;
using Predassert;

namespace BYORulesEngine.UnitTest
{
    [TestClass]
    public class FrequentDinerDiscountRuleTest : RuleEngineTest
    {
        public TestContext TestContext { get; set; }

        [TestInitialize]
        public void Initialize()
        {
            InitializeService(
                new List<IDiscountRule>()
                {
                    new FrequentDinerDiscountRule("Frequent diner", 3.00m, 10, 5.00m)
                },
                new List<IFreeItemsRule>(),
                new List<ICouponRule>()
            );
        }

        [TestMethod]
        public void NoPriorVisitsEarnsNoDiscount()
        {
            Check outputCheck = _service.ExecuteRules(CreateTestCheck());

            Pred.Assert(TotalDiscounts(outputCheck), Is.EqualTo(0.00m));
        }

        [TestMethod]
        public void NinePriorVisitsEarnsNoDiscount()
        {
            AddChecksToHistory(9);
            Check outputCheck = _service.ExecuteRules(CreateTestCheck());

            Pred.Assert(TotalDiscounts(outputCheck), Is.EqualTo(0.00m));
        }

        [TestMethod]
        public void TenPriorVisitsEarnsADiscount()
        {
            AddChecksToHistory(10);
            Check outputCheck = _service.ExecuteRules(CreateTestCheck());

            Pred.Assert(TotalDiscounts(outputCheck), Is.EqualTo(3.00m));
        }

        [TestMethod]
        public void EleventhVisitStartsOver()
        {
            AddChecksToHistory(11);
            Check outputCheck = _service.ExecuteRules(CreateTestCheck());

            Pred.Assert(TotalDiscounts(outputCheck), Is.EqualTo(0.00m));
        }

        [TestMethod]
        public void NineteenStillNoDiscount()
        {
            AddChecksToHistory(19);
            Check outputCheck = _service.ExecuteRules(CreateTestCheck());

            Pred.Assert(TotalDiscounts(outputCheck), Is.EqualTo(0.00m));
        }

        [TestMethod]
        public void TwentySecondDiscount()
        {
            AddChecksToHistory(20);
            Check outputCheck = _service.ExecuteRules(CreateTestCheck());

            Pred.Assert(TotalDiscounts(outputCheck), Is.EqualTo(3.00m));
        }

        private void AddChecksToHistory(int checksToAdd)
        {
            for (int i = 0; i < checksToAdd; i++)
                _mockRepository.AddCheck(_service.ExecuteRules(CreateTestCheck()));
        }

        private Check CreateTestCheck()
        {
            Check check = new Check();
            Item burgers = check.AddItem(BurgerId);
            burgers.UnitPrice = 2.49m;
            burgers.Quantity = 1;
            Item drinks = check.AddItem(DrinkId);
            drinks.UnitPrice = 1.39m;
            drinks.Quantity = 2;
            check.FrequentDiner = _diner;
            return check;
        }

        private decimal TotalDiscounts(Check outputCheck)
        {
            return outputCheck.Discounts
                .Where(discount => discount.Description == "Frequent diner")
                .Sum(discount => discount.Amount);
        }
    }
}
