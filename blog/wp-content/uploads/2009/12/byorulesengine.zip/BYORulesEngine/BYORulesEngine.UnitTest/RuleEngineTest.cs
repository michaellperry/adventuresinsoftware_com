using System;
using BYORulesEngine.Model;
using BYORulesEngine.Service;
using BYORulesEngine.Rules;
using System.Collections.Generic;

namespace BYORulesEngine.UnitTest
{
    public class RuleEngineTest
    {
        protected static ItemId BurgerId = new ItemId(1);
        protected static ItemId FriesId = new ItemId(2);
        protected static ItemId DrinkId = new ItemId(3);
        protected static ItemId IceCreamId = new ItemId(4);

        protected PointOfSaleService _service;
        protected FrequentDiner _diner;
        protected MockRepository _mockRepository;

        protected void InitializeService(List<IDiscountRule> discountRules, List<IFreeItemsRule> freeItemRules, List<ICouponRule> couponRules)
        {
            _mockRepository = new MockRepository();
            _diner = new FrequentDiner();
            _service = new PointOfSaleService(discountRules, freeItemRules, couponRules, _mockRepository);
        }
    }
}
