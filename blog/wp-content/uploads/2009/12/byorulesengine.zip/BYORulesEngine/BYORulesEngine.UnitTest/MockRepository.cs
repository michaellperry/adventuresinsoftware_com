using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BYORulesEngine.Model;
using BYORulesEngine.Service;
using BYORulesEngine.Conditions;
using BYORulesEngine.Rules;
using System.Linq.Expressions;

namespace BYORulesEngine.UnitTest
{
    public class MockRepository : IRepository
    {
        private List<Check> _checkTable = new List<Check>();

        public void AddCheck(Check check)
        {
            _checkTable.Add(check);
        }

        public IEnumerable<Check> GetChecks(Expression<Func<Check, bool>> specification)
        {
            return _checkTable.Where(specification.Compile());
        }
    }
}
