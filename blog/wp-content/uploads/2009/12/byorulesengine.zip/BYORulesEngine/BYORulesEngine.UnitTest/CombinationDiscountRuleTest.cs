﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BYORulesEngine.Service;
using BYORulesEngine.Conditions;
using BYORulesEngine.Model;
using Predassert;
using BYORulesEngine.Rules;

namespace BYORulesEngine.UnitTest
{
    [TestClass]
    public class CombinationDiscountRuleTest : RuleEngineTest
    {
        public TestContext TestContext { get; set; }

        [TestInitialize]
        public void Initialize()
        {
            List<ItemId> comboItems = new List<ItemId>()
            {
                BurgerId, 
                FriesId, 
                DrinkId
            };
            CombinationDiscountRule comboRule = new CombinationDiscountRule("Value meal", 0.80m, comboItems);
            InitializeService(
                new List<IDiscountRule>() { comboRule },
                new List<IFreeItemsRule>(),
                new List<ICouponRule>()
            );
        }

        [TestMethod]
        public void BlankCheckGetsNoDiscount()
        {
            Check check = new Check();
            Check checkWithDiscounts = _service.ExecuteRules(check);

            Pred.Assert(checkWithDiscounts.Discounts, Is.Empty<Discount>());
        }

        [TestMethod]
        public void CheckWithSomeItemsGetsNoDiscount()
        {
            Check check = new Check();
            check.AddItem(BurgerId).Quantity = 1;
            check.AddItem(FriesId).Quantity = 1;
            Check checkWithDiscounts = _service.ExecuteRules(check);

            Pred.Assert(checkWithDiscounts.Discounts, Is.Empty<Discount>());
        }

        [TestMethod]
        public void CheckWithAllItemsGetsADiscount()
        {
            Check check = new Check();
            check.AddItem(BurgerId).Quantity = 1;
            check.AddItem(FriesId).Quantity = 1;
            check.AddItem(DrinkId).Quantity = 1;
            Check checkWithDiscounts = _service.ExecuteRules(check);

            Pred.Assert(checkWithDiscounts.Discounts.Count(), Is.EqualTo(1));
            AssertHasValueMealDiscount(checkWithDiscounts);
        }

        [TestMethod]
        public void CheckWithExtraItemsGetsOneDiscount()
        {
            Check check = new Check();
            check.AddItem(BurgerId).Quantity = 2;
            check.AddItem(FriesId).Quantity = 2;
            check.AddItem(DrinkId).Quantity = 1;
            Check checkWithDiscounts = _service.ExecuteRules(check);

            Pred.Assert(checkWithDiscounts.Discounts.Count(), Is.EqualTo(1));
            AssertHasValueMealDiscount(checkWithDiscounts);
        }

        [TestMethod]
        public void CheckWithTwoCombosGetsTwoDiscounts()
        {
            Check check = new Check();
            check.AddItem(BurgerId).Quantity = 2;
            check.AddItem(FriesId).Quantity = 2;
            check.AddItem(DrinkId).Quantity = 2;
            Check checkWithDiscounts = _service.ExecuteRules(check);

            Pred.Assert(checkWithDiscounts.Discounts.Count(), Is.EqualTo(2));
            AssertHasValueMealDiscount(checkWithDiscounts);
        }

        private static void AssertHasValueMealDiscount(Check checkWithDiscounts)
        {
            Pred.Assert(checkWithDiscounts.Discounts, Contains<Discount>.That(
                Has<Discount>.Property(discount => discount.Description, Is.EqualTo("Value meal"))
                .And(Has<Discount>.Property(discount => discount.Amount, Is.EqualTo(0.80m)))
            ));
        }
    }
}
