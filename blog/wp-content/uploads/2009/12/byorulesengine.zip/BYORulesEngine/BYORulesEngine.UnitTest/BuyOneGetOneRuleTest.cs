﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BYORulesEngine.Model;
using BYORulesEngine.Service;
using BYORulesEngine.Rules;
using BYORulesEngine.Conditions;
using Predassert;

namespace BYORulesEngine.UnitTest
{
    [TestClass]
    public class BuyOneGetOneRuleTest : RuleEngineTest
    {
        public TestContext TestContext { get; set; }

        [TestInitialize]
        public void Initialize()
        {
            InitializeService(
                new List<IDiscountRule>(),
                new List<IFreeItemsRule>() { new BuyOneGetOneRule(5, BurgerId, 2, IceCreamId) },
                new List<ICouponRule>()
            );
        }

        [TestMethod]
        public void EmptyCheckGetsNoFreeItems()
        {
            Check check = new Check();
            Check outputCheck = _service.ExecuteRules(check);

            Pred.Assert(outputCheck.Items, Is.Empty<Item>());
        }

        [TestMethod]
        public void NotEnoughItemsGetsNoFreeItem()
        {
            Check check = new Check();
            Item burger = check.AddItem(BurgerId);
            burger.Quantity = 1;
            burger.UnitPrice = 2.49m;
            Check outputCheck = _service.ExecuteRules(check);

            AssertContainsNoFreeItem(outputCheck);
        }

        [TestMethod]
        public void FiveBurgersGetTwoFreeIceCreams()
        {
            Check check = new Check();
            Item burger = check.AddItem(BurgerId);
            burger.Quantity = 5;
            burger.UnitPrice = 2.49m;
            Check outputCheck = _service.ExecuteRules(check);

            Pred.Assert(CountFreeIceCreams(outputCheck), Is.EqualTo(2));
        }

        [TestMethod]
        public void NineBurgersGetTwoFreeIceCreams()
        {
            Check check = new Check();
            Item burger = check.AddItem(BurgerId);
            burger.Quantity = 9;
            burger.UnitPrice = 2.49m;
            Check outputCheck = _service.ExecuteRules(check);

            Pred.Assert(CountFreeIceCreams(outputCheck), Is.EqualTo(2));
        }

        [TestMethod]
        public void TenBurgersGetFourFreeIceCreams()
        {
            Check check = new Check();
            Item burger = check.AddItem(BurgerId);
            burger.Quantity = 10;
            burger.UnitPrice = 2.49m;
            Check outputCheck = _service.ExecuteRules(check);

            Pred.Assert(CountFreeIceCreams(outputCheck), Is.EqualTo(4));
        }

        private static void AssertContainsNoFreeItem(Check outputCheck)
        {
		    Pred.Assert(outputCheck.Items, ContainsNo<Item>.That(
                Has<Item>.Property(item => item.UnitPrice, Is.EqualTo(0.0m))));
        }

        private int CountFreeIceCreams(Check outputCheck)
        {
            return outputCheck.Items
                .Where(item => item.ItemId == IceCreamId && item.UnitPrice == 0.0m)
                .Sum(item => item.Quantity);
        }
    }
}
