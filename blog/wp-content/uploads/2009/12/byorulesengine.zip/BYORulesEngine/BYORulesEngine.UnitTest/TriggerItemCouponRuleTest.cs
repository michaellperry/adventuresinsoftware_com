﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BYORulesEngine.Model;
using BYORulesEngine.Service;
using BYORulesEngine.Rules;
using BYORulesEngine.Conditions;
using Predassert;

namespace BYORulesEngine.UnitTest
{
    [TestClass]
    public class TriggerItemCouponRuleTest : RuleEngineTest
    {
        public TestContext TestContext { get; set; }

        [TestInitialize]
        public void Initialize()
        {
            InitializeService(
                new List<IDiscountRule>(),
                new List<IFreeItemsRule>(),
                new List<ICouponRule> { new TriggerItemCouponRule(1, IceCreamId, "Half off") }
            );
        }

        [TestMethod]
        public void EmptyCheckGetsNoCoupon()
        {
            Check check = new Check();
            Check outputCheck = _service.ExecuteRules(check);

            Pred.Assert(outputCheck.Coupons, Is.Empty<Coupon>());
        }

        [TestMethod]
        public void WrongItemGetsNoCoupon()
        {
            Check check = new Check();
            check.AddItem(BurgerId).Quantity = 1;
            Check outputCheck = _service.ExecuteRules(check);

            Pred.Assert(outputCheck.Coupons, Is.Empty<Coupon>());
        }

        [TestMethod]
        public void RightItemGetsACoupon()
        {
            Check check = new Check();
            check.AddItem(IceCreamId).Quantity = 1;
            Check outputCheck = _service.ExecuteRules(check);

            Pred.Assert(outputCheck.Coupons.Count(), Is.EqualTo(1));
        }

        [TestMethod]
        public void TwoItemsGetsTwoCoupons()
        {
            Check check = new Check();
            check.AddItem(IceCreamId).Quantity = 2;
            Check outputCheck = _service.ExecuteRules(check);

            Pred.Assert(outputCheck.Coupons.Count(), Is.EqualTo(2));
        }
    }
}
