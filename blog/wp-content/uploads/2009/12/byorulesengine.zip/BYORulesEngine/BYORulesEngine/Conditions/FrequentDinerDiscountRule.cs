﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BYORulesEngine.Rules;
using BYORulesEngine.Model;

namespace BYORulesEngine.Conditions
{
    public class FrequentDinerDiscountRule : IDiscountRule
    {
        private string _discountDescription;
        private decimal _discountAmount;
        private int _priorVisitsRequired;
        private decimal _minimumAmountPerVisit;

        public FrequentDinerDiscountRule(
            string discountDescription,
            decimal discountAmount,
            int priorVisitsRequired,
            decimal minimumAmountPerVisit)
        {
            _discountDescription = discountDescription;
            _discountAmount = discountAmount;
            _priorVisitsRequired = priorVisitsRequired;
            _minimumAmountPerVisit = minimumAmountPerVisit;
        }

        public IEnumerable<Discount> GetDiscounts(RuleModel ruleModel)
        {
            if (ruleModel.Check.Total >= _minimumAmountPerVisit)
            {
                // Search the history for actual prior visits.
                int priorVisitCountActual = ruleModel.GetPriorVisitCount(ruleModel.Check.FrequentDiner, _minimumAmountPerVisit);

                // If we have enough, yield the discount.
                if (priorVisitCountActual >= _priorVisitsRequired)
                {
                    int discountsEarned = priorVisitCountActual / _priorVisitsRequired;
                    yield return new PriorVisitDiscount(
                        _discountDescription,
                        discountsEarned * _discountAmount,
                        discountsEarned * _priorVisitsRequired);
                }
            }
        }
    }
}
