﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BYORulesEngine.Model
{
    public class Item
    {
        private ItemId _itemId;
        private decimal _unitPrice;
        private int _quantity;

        public Item(ItemId itemId)
        {
            _itemId = itemId;
        }

        public ItemId ItemId
        {
            get { return _itemId; }
        }

        public decimal UnitPrice
        {
            get { return _unitPrice; }
            set { _unitPrice = value; }
        }

        public int Quantity
        {
            get { return _quantity; }
            set { _quantity = value; }
        }

        public decimal Total
        {
            get { return _unitPrice * _quantity; }
        }

        public Item CreateCopy()
        {
            Item copy = new Item(_itemId);
            copy._quantity = _quantity;
            copy._unitPrice = _unitPrice;
            return copy;
        }
    }
}
