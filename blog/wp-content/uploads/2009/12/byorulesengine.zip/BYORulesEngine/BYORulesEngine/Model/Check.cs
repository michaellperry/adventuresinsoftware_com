﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace BYORulesEngine.Model
{
    public class Check
    {
        private List<Item> _items = new List<Item>();
        private List<Discount> _discounts = new List<Discount>();
        private List<Coupon> _coupons = new List<Coupon>();
        private FrequentDiner _frequentDiner;

        public IEnumerable<Item> Items
        {
            get { return _items; }
        }

        public IEnumerable<Discount> Discounts
        {
            get { return _discounts; }
        }

        public IEnumerable<Coupon> Coupons
        {
            get { return _coupons; }
        }

        public Item AddItem(ItemId itemId)
        {
            Item item = new Item(itemId);
            _items.Add(item);
            return item;
        }

        public void AddItems(IEnumerable<Item> items)
        {
            _items.AddRange(items);
        }

        public void AddDiscounts(IEnumerable<Discount> discounts)
        {
            _discounts.AddRange(discounts);
        }

        public void AddCoupons(IEnumerable<Coupon> coupons)
        {
            _coupons.AddRange(coupons);
        }

        public FrequentDiner FrequentDiner
        {
            get { return _frequentDiner; }
            set { _frequentDiner = value; }
        }

        public decimal Total
        {
            get { return TotalBeforeDiscounts - _discounts.Sum(discount => discount.Amount); }
        }

        public decimal TotalBeforeDiscounts
        {
            get { return _items.Sum(item => item.Total); }
        }

        public Check CreateCopy()
        {
            Check copy = new Check();
            copy._items = new List<Item>(_items.Select(item => item.CreateCopy()));
            copy._discounts = new List<Discount>(_discounts.Select(discount => discount.CreateCopy()));
            copy._frequentDiner = _frequentDiner;
            return copy;
        }
    }
}
