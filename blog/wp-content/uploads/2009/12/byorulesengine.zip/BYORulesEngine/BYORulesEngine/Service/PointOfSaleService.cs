﻿using System;
using System.Collections.Generic;
using System.Linq;
using BYORulesEngine.Model;
using BYORulesEngine.Rules;

namespace BYORulesEngine.Service
{
    public class PointOfSaleService
    {
        private List<IDiscountRule> _discountRules;
        private List<IFreeItemsRule> _freeItemsRules;
        private List<ICouponRule> _couponRules;
        private IRepository _repository;

        public PointOfSaleService(
            IEnumerable<IDiscountRule> discountRules,
            IEnumerable<IFreeItemsRule> freeItemsRules,
            IEnumerable<ICouponRule> couponRules,
            IRepository repository)
        {
            _discountRules = discountRules.ToList();
            _freeItemsRules = freeItemsRules.ToList();
            _couponRules = couponRules.ToList();
            _repository = repository;
        }

        public Check ExecuteRules(Check check)
        {
            Check copy = check.CreateCopy();
            RuleModel ruleModel = new RuleModel(check, _repository);
            copy.AddItems(_freeItemsRules.SelectMany(rule => rule.GetFreeItems(ruleModel)));
            copy.AddDiscounts(_discountRules.SelectMany(rule => rule.GetDiscounts(ruleModel)));
            copy.AddCoupons(_couponRules.SelectMany(rule => rule.GetCoupons(ruleModel)));
            return copy;
        }
    }
}
