using System;

namespace BYORulesEngine.Model
{
    public class FrequentDiner
    {
    }
}
