using System;
using System.Collections.Generic;
using BYORulesEngine.Model;

namespace BYORulesEngine.Rules
{
    public interface IDiscountRule
    {
        IEnumerable<Discount> GetDiscounts(RuleModel ruleModel);
    }
}
