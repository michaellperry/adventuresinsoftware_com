﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BYORulesEngine.Rules;
using BYORulesEngine.Model;

namespace BYORulesEngine.Conditions
{
    public class TriggerItemCouponRule : ICouponRule
    {
        private int _triggerItemCountRequired;
        private ItemId _triggerItemId;
        private string _couponText;

        public TriggerItemCouponRule(int triggerItemCountRequired, ItemId triggerItemId, string couponText)
        {
            _triggerItemCountRequired = triggerItemCountRequired;
            _triggerItemId = triggerItemId;
            _couponText = couponText;
        }

        public IEnumerable<Coupon> GetCoupons(RuleModel ruleModel)
        {
            // Count the number of trigger items.
            int triggerItemCountActual = ruleModel.Check.Items
                .Where(item => item.ItemId == _triggerItemId)
                .Sum(item => item.Quantity);

            // Yield a coupon for each set of trigger items.
            int couponsToPrint = triggerItemCountActual / _triggerItemCountRequired;
            for (int i = 0; i < couponsToPrint; i++)
                yield return new Coupon(_couponText);
        }
    }
}
