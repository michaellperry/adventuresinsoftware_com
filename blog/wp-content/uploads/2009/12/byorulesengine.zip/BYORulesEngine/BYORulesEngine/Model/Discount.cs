﻿using System;

namespace BYORulesEngine.Model
{
    public class Discount
    {
        private string _description;
        private decimal _amount;

        public Discount(string description, decimal amount)
        {
            _description = description;
            _amount = amount;
        }

        public string Description
        {
            get { return _description; }
        }

        public decimal Amount
        {
            get { return _amount; }
        }

        public Discount CreateCopy()
        {
            return new Discount(_description, _amount);
        }
    }
}
