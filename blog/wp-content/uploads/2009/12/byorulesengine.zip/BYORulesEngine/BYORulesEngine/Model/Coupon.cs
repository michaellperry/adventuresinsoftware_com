﻿using System;

namespace BYORulesEngine.Model
{
    public class Coupon
    {
        private string _text;

        public Coupon(string text)
        {
            _text = text;
        }

        public string Text
        {
            get { return _text; }
        }
    }
}
