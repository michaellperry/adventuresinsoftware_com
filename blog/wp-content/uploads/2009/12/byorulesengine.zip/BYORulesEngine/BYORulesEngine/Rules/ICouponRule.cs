﻿using System;
using System.Collections.Generic;
using BYORulesEngine.Model;

namespace BYORulesEngine.Rules
{
    public interface ICouponRule
    {
        IEnumerable<Coupon> GetCoupons(RuleModel ruleModel);
    }
}
