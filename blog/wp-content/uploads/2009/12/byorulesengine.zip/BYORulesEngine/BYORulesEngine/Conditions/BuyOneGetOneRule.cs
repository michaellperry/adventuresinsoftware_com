﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BYORulesEngine.Rules;
using BYORulesEngine.Model;

namespace BYORulesEngine.Conditions
{
    public class BuyOneGetOneRule : IFreeItemsRule
    {
        private int _triggerItemCountRequired;
        private ItemId _triggerItemId;
        private int _promotionalItemCount;
        private ItemId _promotionalItemId;

        public BuyOneGetOneRule(int triggerItemCountRequired, ItemId triggerItemId, int promotionalItemCount, ItemId promotionalItemId)
        {
            _triggerItemCountRequired = triggerItemCountRequired;
            _triggerItemId = triggerItemId;
            _promotionalItemCount = promotionalItemCount;
            _promotionalItemId = promotionalItemId;
        }

        public IEnumerable<Item> GetFreeItems(RuleModel ruleModel)
        {
            // Count the number of trigger items.
            int triggerItemCountActual = ruleModel.Check.Items
                .Where(item => item.ItemId == _triggerItemId)
                .Sum(item => item.Quantity);

            // If we have enough, yield the promotional item.
            if (triggerItemCountActual >= _triggerItemCountRequired)
                yield return new Item(_promotionalItemId)
                {
                    Quantity = triggerItemCountActual / _triggerItemCountRequired * _promotionalItemCount
                };
        }
    }
}
