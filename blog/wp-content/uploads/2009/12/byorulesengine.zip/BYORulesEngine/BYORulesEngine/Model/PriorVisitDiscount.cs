using System;

namespace BYORulesEngine.Model
{
    public class PriorVisitDiscount : Discount
    {
        private int _visitsCounted;

        public PriorVisitDiscount(string description, decimal amount, int visitsCounted)
            : base(description, amount)
        {
            _visitsCounted = visitsCounted;
        }

        public int VisitsCounted
        {
            get { return _visitsCounted; }
        }
    }
}
