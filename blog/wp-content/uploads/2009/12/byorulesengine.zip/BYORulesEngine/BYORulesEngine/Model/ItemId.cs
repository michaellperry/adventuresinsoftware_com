﻿using System;

namespace BYORulesEngine.Model
{
    public class ItemId
    {
        private int _id;

        public ItemId(int id)
        {
            _id = id;
        }

        public int Id
        {
            get { return _id; }
        }
    }
}
