﻿using System;
using System.Linq;
using BYORulesEngine.Model;

namespace BYORulesEngine.Rules
{
    public class RuleModel
    {
        private Check _check;
        private IRepository _repository;

        public RuleModel(Check check, IRepository repository)
        {
            _check = check;
            _repository = repository;
        }

        public Check Check
        {
            get { return _check; }
        }

        public int GetPriorVisitCount(FrequentDiner frequentDiner, decimal minimumAmountPerVisit)
        {
            int totalPriorVisitCount = _repository
                .GetChecks(check => check.FrequentDiner == frequentDiner && check.TotalBeforeDiscounts > minimumAmountPerVisit)
                .Count();
            int discountedPriorVisitCount = _repository
                .GetChecks(check => check.FrequentDiner == frequentDiner)
                .SelectMany(check => check.Discounts)
                .OfType<PriorVisitDiscount>()
                .Sum(discount => discount.VisitsCounted);
            return totalPriorVisitCount - discountedPriorVisitCount;
        }
    }
}
