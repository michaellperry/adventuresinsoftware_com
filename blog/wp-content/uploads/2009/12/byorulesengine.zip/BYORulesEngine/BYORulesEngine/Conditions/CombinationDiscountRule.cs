﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BYORulesEngine.Rules;
using BYORulesEngine.Model;

namespace BYORulesEngine.Conditions
{
    public class CombinationDiscountRule : IDiscountRule
    {
        private string _description;
        private decimal _amount;
        private List<ItemId> _triggerItems;

        public CombinationDiscountRule(string description, decimal amount, List<ItemId> triggerItems)
        {
            _description = description;
            _amount = amount;
            _triggerItems = triggerItems;
        }

        public IEnumerable<Discount> GetDiscounts(RuleModel ruleModel)
        {
            // Get the minimum quantity of all trigger items.
            int comboCount = _triggerItems
                .Select(triggerItemId => ruleModel.Check
                    .Items
                    .Where(item => item.ItemId == triggerItemId)
                    .Sum(item => item.Quantity))
                .Min();
            for (int i = 0; i < comboCount; i++)
                yield return new Discount(_description, _amount);
        }
    }
}
