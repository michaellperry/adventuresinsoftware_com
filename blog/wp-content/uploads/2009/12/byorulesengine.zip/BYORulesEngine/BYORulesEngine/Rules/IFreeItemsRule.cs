using System;
using System.Collections.Generic;
using BYORulesEngine.Model;

namespace BYORulesEngine.Rules
{
    public interface IFreeItemsRule
    {
        IEnumerable<Item> GetFreeItems(RuleModel ruleModel);
    }
}
