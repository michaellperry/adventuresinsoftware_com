using System;
using UpdateControls.Fields;

namespace ToDoList.Models
{
    public class NavigationModel
    {
        private Independent<User> _currentUser = new Independent<User>();
        private Independent<string> _userName = new Independent<string>();
        private Independent<string> _taskName = new Independent<string>();
        private Independent<Task> _selectedTask = new Independent<Task>();

        public User CurrentUser
        {
            get { return _currentUser; }
            set { _currentUser.Value = value; }
        }

        public string UserName
        {
            get { return _userName; }
            set { _userName.Value = value; }
        }

        public string TaskName
        {
            get { return _taskName; }
            set { _taskName.Value = value; }
        }

        public Task SelectedTask
        {
            get { return _selectedTask; }
            set { _selectedTask.Value = value; }
        }
    }
}
