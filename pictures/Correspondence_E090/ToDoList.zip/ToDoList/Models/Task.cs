﻿
namespace ToDoList.Models
{
    public partial class Task
    {
        public void Complete()
        {
            Community.AddFact(new TaskCompleted(this));
        }
    }
}
