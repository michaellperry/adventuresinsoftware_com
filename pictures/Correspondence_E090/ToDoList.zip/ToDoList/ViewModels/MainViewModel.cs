using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Input;
using ToDoList.Models;
using UpdateControls.Correspondence;
using UpdateControls.XAML;

namespace ToDoList.ViewModels
{
    public class MainViewModel
    {
        private Community _community;
        private NavigationModel _navigationModel;

        public MainViewModel(Community community, NavigationModel navigationModel)
        {
            _community = community;
            _navigationModel = navigationModel;
        }

        public string UserName
        {
            get
            {
                if (!String.IsNullOrEmpty(_navigationModel.UserName))
                    return _navigationModel.UserName;
                else if (_navigationModel.CurrentUser != null)
                    return _navigationModel.CurrentUser.UserName;
                else
                    return String.Empty;
            }
            set { _navigationModel.UserName = value; }
        }

        public ICommand LogIn
        {
            get
            {
                return MakeCommand
                    .When(() => !String.IsNullOrEmpty(_navigationModel.UserName))
                    .Do(() =>
                    {
                        User user = _community.AddFact(new User(_navigationModel.UserName));
                        _navigationModel.CurrentUser = user;
                        _navigationModel.UserName = string.Empty;
                    });
            }
        }

        public IEnumerable<TaskViewModel> OpenTasks
        {
            get
            {
                if (_navigationModel.CurrentUser != null)
                    return
                        from Task t in _navigationModel.CurrentUser.OpenTasks
                        select new TaskViewModel(t);
                else
                    return Enumerable.Empty<TaskViewModel>();
            }
        }

        public TaskViewModel SelectedTask
        {
            get
            {
                return _navigationModel.SelectedTask == null
                    ? null
                    : new TaskViewModel(_navigationModel.SelectedTask);
            }
            set
            {
            	_navigationModel.SelectedTask = value == null
                    ? null
                    : value.Task;
            }
        }

        public string TaskName
        {
            get
            {
                if (!String.IsNullOrEmpty(_navigationModel.TaskName))
                    return _navigationModel.TaskName;
                else if (_navigationModel.SelectedTask != null)
                    return _navigationModel.SelectedTask.Name;
                else
                    return String.Empty;
            }
            set { _navigationModel.TaskName = value; }
        }

        public ICommand AddTask
        {
            get
            {
                return MakeCommand
                    .When(() =>
                        _navigationModel.CurrentUser != null &&
                        !String.IsNullOrEmpty(_navigationModel.TaskName))
                    .Do(() =>
                    {
                        Task task = _community.AddFact(new Task(_navigationModel.CurrentUser));
                        task.Name = _navigationModel.TaskName;
                        _navigationModel.TaskName = String.Empty;
                    });
            }
        }

        public ICommand UpdateTask
        {
            get
            {
                return MakeCommand
                    .When(() =>
                        _navigationModel.SelectedTask != null &&
                        !String.IsNullOrEmpty(_navigationModel.TaskName))
                    .Do(() =>
                    {
                        _navigationModel.SelectedTask.Name = _navigationModel.TaskName;
                        _navigationModel.TaskName = String.Empty;
                    });
            }
        }

        public ICommand CompleteTask
        {
            get
            {
                return MakeCommand
                    .When(() => _navigationModel.SelectedTask != null)
                    .Do(() =>
                    {
                        _navigationModel.SelectedTask.Complete();
                    });
            }
        }
    }
}
