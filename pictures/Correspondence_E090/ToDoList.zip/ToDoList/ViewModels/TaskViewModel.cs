using System;
using ToDoList.Models;

namespace ToDoList.ViewModels
{
    public class TaskViewModel
    {
        private readonly Task _task;

        public TaskViewModel(Task task)
        {
            _task = task;
        }

        internal Task Task
        {
            get { return _task; }
        }

        public string Name
        {
            get { return _task.Name; }
        }
    }
}
