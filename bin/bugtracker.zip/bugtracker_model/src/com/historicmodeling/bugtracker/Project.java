package com.historicmodeling.bugtracker;

import java.util.UUID;

import com.updatecontrols.correspondence.Correspondence;
import com.updatecontrols.correspondence.CorrespondenceObject;
import com.updatecontrols.correspondence.Field;
import com.updatecontrols.correspondence.Query;
import com.updatecontrols.correspondence.memento.Memento;

@Correspondence
public class Project extends CorrespondenceObject {

	private Query<ProjectName> name = new Query<ProjectName>(this)
		.joinSuccessors("project_name");
	private Query<Issue> issue = new Query<Issue>(this)
		.joinSuccessors("project_issue");

	private @Field UUID id;

	public Project() {
		id = UUID.randomUUID();
	}

	public Project(Memento memento) {
	}

	public String getName() {
		// Get the most recent leaf.
		ProjectName leaf = name.getLast();
		if (leaf == null)
			return "<New project>";
		else
			return leaf.getName();
	}

	public void setName(String name) {
		getCommunity().addObject(new ProjectName(this, this.name.getObjectList(), name));
	}

	public Iterable<Issue> getIssues() {
		return issue;
	}

}
