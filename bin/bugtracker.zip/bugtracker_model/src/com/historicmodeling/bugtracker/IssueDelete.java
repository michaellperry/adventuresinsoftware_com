package com.historicmodeling.bugtracker;

import java.util.UUID;

import com.updatecontrols.correspondence.Correspondence;
import com.updatecontrols.correspondence.CorrespondenceException;
import com.updatecontrols.correspondence.CorrespondenceObject;
import com.updatecontrols.correspondence.Field;
import com.updatecontrols.correspondence.PredecessorObj;
import com.updatecontrols.correspondence.Query;
import com.updatecontrols.correspondence.memento.Memento;

@Correspondence
public class IssueDelete extends CorrespondenceObject {

	// Issue that was deleted.
	private PredecessorObj<Issue> issue;

	// Query for restore.
	private Query<IssueRestore> restore = new Query<IssueRestore>(this)
		.joinSuccessors("undo");

	// Identity.
	private @Field UUID id;

	public IssueDelete(Issue issue) {
		this.issue = new PredecessorObj<Issue>(this, "issue_delete", issue);
		id = UUID.randomUUID();
	}

	public IssueDelete(Memento memento) throws CorrespondenceException {
		this.issue = new PredecessorObj<Issue>(this, "issue_delete", memento);
	}

	@Override
	protected boolean exists() {
		return restore.isEmpty();
	}

	public void restore() {
		getCommunity().addObject(new IssueRestore(this));
	}
}
