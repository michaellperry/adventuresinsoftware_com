package com.historicmodeling.bugtracker;

import com.updatecontrols.correspondence.Correspondence;
import com.updatecontrols.correspondence.CorrespondenceException;
import com.updatecontrols.correspondence.CorrespondenceObject;
import com.updatecontrols.correspondence.PredecessorObj;
import com.updatecontrols.correspondence.memento.Memento;

@Correspondence
public class IssueRestore extends CorrespondenceObject {

	// The deletion to undo.
	private PredecessorObj<IssueDelete> delete;

	public IssueRestore(IssueDelete delete) {
		this.delete = new PredecessorObj<IssueDelete>(this, "undo", delete);
	}

	public IssueRestore(Memento memento) throws CorrespondenceException {
		this.delete = new PredecessorObj<IssueDelete>(this, "undo", memento);
	}
}
