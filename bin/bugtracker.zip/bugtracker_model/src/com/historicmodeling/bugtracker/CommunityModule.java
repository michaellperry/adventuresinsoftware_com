package com.historicmodeling.bugtracker;

import com.updatecontrols.correspondence.Community;
import com.updatecontrols.correspondence.CorrespondenceException;
import com.updatecontrols.correspondence.Module;

public class CommunityModule implements Module {

	@Override
	public void registerTypes(Community community) throws CorrespondenceException {
		community
			.addType(Project.class)
			.addType(ProjectName.class)
			.addType(Issue.class)
			.addType(IssueDelete.class)
			.addType(IssueRestore.class);
	}

}
