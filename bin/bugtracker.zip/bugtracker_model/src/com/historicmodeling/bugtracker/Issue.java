package com.historicmodeling.bugtracker;

import java.util.UUID;

import com.updatecontrols.correspondence.Correspondence;
import com.updatecontrols.correspondence.CorrespondenceException;
import com.updatecontrols.correspondence.CorrespondenceObject;
import com.updatecontrols.correspondence.Field;
import com.updatecontrols.correspondence.PredecessorObj;
import com.updatecontrols.correspondence.Query;
import com.updatecontrols.correspondence.memento.Memento;

@Correspondence
public class Issue extends CorrespondenceObject {

	// The project to which this issue belogs.
	private PredecessorObj<Project> project;

	// Query for deletion of this issue.
	private Query<IssueDelete> delete = new Query<IssueDelete>(this)
		.joinSuccessors("issue_delete");

	// Identity.
	private @Field UUID id;

	public Issue(Project project) {
		this.project = new PredecessorObj<Project>(this, "project_issue", project);
		this.id = UUID.randomUUID();
	}

	public Issue(Memento memento) throws CorrespondenceException {
		this.project = new PredecessorObj<Project>(this, "project_issue", memento);
	}

	public Project getProject() {
		return project.getObject();
	}

	@Override
	protected boolean exists() {
		return delete.isEmpty();
	}

	public void delete() {
		getCommunity().addObject(new IssueDelete(this));
	}

	public void restore() {
		for (IssueDelete d: delete) {
			d.restore();
		}
	}
}