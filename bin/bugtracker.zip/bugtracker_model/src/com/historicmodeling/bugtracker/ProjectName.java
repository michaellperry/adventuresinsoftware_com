package com.historicmodeling.bugtracker;

import com.updatecontrols.correspondence.Correspondence;
import com.updatecontrols.correspondence.CorrespondenceException;
import com.updatecontrols.correspondence.CorrespondenceObject;
import com.updatecontrols.correspondence.Field;
import com.updatecontrols.correspondence.ObjectList;
import com.updatecontrols.correspondence.PredecessorObj;
import com.updatecontrols.correspondence.PredecessorSet;
import com.updatecontrols.correspondence.Query;
import com.updatecontrols.correspondence.memento.Memento;

@Correspondence
public class ProjectName extends CorrespondenceObject {

	private PredecessorObj<Project> project;
	private PredecessorSet<ProjectName> prior;

	private Query<ProjectName> next = new Query<ProjectName>(this)
		.joinSuccessors("next");

	private @Field String name;

	public ProjectName(Project project, ObjectList<ProjectName> prior, String name) {
		this.project = new PredecessorObj<Project>(this, "project_name", project);
		this.prior = new PredecessorSet<ProjectName>(this, "next", prior);

		this.name = name;
	}

	public ProjectName(Memento memento) throws CorrespondenceException {
		this.project = new PredecessorObj<Project>(this, "project_name", memento);
		this.prior = new PredecessorSet<ProjectName>(this, "next", memento);
	}

	@Override
	protected boolean exists() {
		return next.isVoid();
	}

	public String getName() {
		return name;
	}

}
