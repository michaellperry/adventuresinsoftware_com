package com.historicmodeling.bugtracker.test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.historicmodeling.bugtracker.CommunityModule;
import com.historicmodeling.bugtracker.Issue;
import com.historicmodeling.bugtracker.Project;
import com.updatecontrols.correspondence.Community;
import com.updatecontrols.correspondence.Module;
import com.updatecontrols.correspondence.postgres.PostgresConfig;
import com.updatecontrols.correspondence.postgres.PostgresStorageStrategy;


public class ProjectTest {
	
	private Community community;
	
	@Before
	public void setup() throws Exception {
		// Create a community and use Postgres to persist objects.
		PostgresConfig config = new PostgresConfig();
		config.setHost("localhost");
		config.setPort(5432);
		config.setDatabase("correspondence");
		config.setRole("correspondence_user");
		config.setPassword("correspondence_password");
		community = new Community(new PostgresStorageStrategy(config));
		
		// Add the bug tracker module to the community.
		List<Module> modules = new ArrayList<Module>();
		modules.add(new CommunityModule());
		community.setModules(modules);
	}

	@Test
	public void testProjectNoName() {
		// Create a project.
		Project project = community.addObject(new Project());
		String name = project.getName();
		
		assertEquals("<New project>", name);
	}

	@Test
	public void testProjectName() {
		// Create a project.
		Project project = community.addObject(new Project());
		// Set the name.
		project.setName("WSE");
		String name = project.getName();
		
		assertEquals("WSE", name);
	}

	@Test
	public void testProjectRename() {
		// Create a project.
		Project project = community.addObject(new Project());
		// Set the name twice.
		project.setName("WSE");
		project.setName("Indigo");
		String name = project.getName();
		
		assertEquals("Indigo", name);
	}
	
	@Test
	public void testIssue() {
		// Create a project.
		Project project = community.addObject(new Project());
		// Create an issue.
		Issue issue = community.addObject(new Issue(project));
		
		// Ensure that the issue is part of the project.
		List<Issue> issues = new ArrayList<Issue>();
		for (Issue i: project.getIssues()) {
			issues.add(i);
		}
		
		assertEquals(1, issues.size());
		assertEquals(issue, issues.get(0));
	}
	
	@Test
	public void testTwoIssues() {
		// Create a project.
		Project project = community.addObject(new Project());
		// Create two issues.
		Issue issue1 = community.addObject(new Issue(project));
		Issue issue2 = community.addObject(new Issue(project));
		
		// Ensure that both issues are part of the project.
		List<Issue> issues = new ArrayList<Issue>();
		for (Issue i: project.getIssues()) {
			issues.add(i);
		}
		
		assertEquals(2, issues.size());
		assertEquals(issue1, issues.get(0));
		assertEquals(issue2, issues.get(1));
	}
	
	@Test
	public void testDeleteIssue() {
		// Create a project.
		Project project = community.addObject(new Project());
		// Create two issues.
		Issue issue1 = community.addObject(new Issue(project));
		Issue issue2 = community.addObject(new Issue(project));
		// Delete the first.
		issue1.delete();
		
		// Ensure that the second issue is part of the project.
		List<Issue> issues = new ArrayList<Issue>();
		for (Issue i: project.getIssues()) {
			issues.add(i);
		}
		
		assertEquals(1, issues.size());
		assertEquals(issue2, issues.get(0));
	}
	
	@Test
	public void testRestoreIssue() {
		// Create a project.
		Project project = community.addObject(new Project());
		// Create two issues.
		Issue issue1 = community.addObject(new Issue(project));
		Issue issue2 = community.addObject(new Issue(project));
		// Delete the first.
		issue1.delete();
		// And restore it.
		issue1.restore();
		
		// Ensure that both issues are part of the project.
		List<Issue> issues = new ArrayList<Issue>();
		for (Issue i: project.getIssues()) {
			issues.add(i);
		}
		
		assertEquals(2, issues.size());
		assertEquals(issue1, issues.get(0));
		assertEquals(issue2, issues.get(1));
	}
}
