delete from index_date;
delete from index;
delete from predecessor;
delete from object;
delete from role;
delete from type;
