--
-- PostgreSQL database dump
--

SET client_encoding = 'WIN1252';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

--
-- Name: plpgsql; Type: PROCEDURAL LANGUAGE; Schema: -; Owner: postgres
--

CREATE PROCEDURAL LANGUAGE plpgsql;


ALTER PROCEDURAL LANGUAGE plpgsql OWNER TO postgres;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

DROP ROLE IF EXISTS correspondence_user;
CREATE ROLE correspondence_user LOGIN ENCRYPTED PASSWORD 'md523b75a71ab9a43b6f83cc7f004017d22'
  NOINHERIT
   VALID UNTIL 'infinity';

--
-- Name: index; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE index (
    index_id integer NOT NULL,
    index_name character varying(255) NOT NULL
);


ALTER TABLE public.index OWNER TO postgres;

--
-- Name: index_date; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE index_date (
    object_id bigint NOT NULL,
    index_id integer NOT NULL,
    value date NOT NULL
);


ALTER TABLE public.index_date OWNER TO postgres;

--
-- Name: object; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE object (
    object_id bigint NOT NULL,
    type_id integer NOT NULL,
    "version" integer NOT NULL,
    data bytea NOT NULL,
    hashcode integer NOT NULL
);


ALTER TABLE public.object OWNER TO postgres;

--
-- Name: predecessor; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE predecessor (
    object_id bigint NOT NULL,
    role_id integer NOT NULL,
    predecessor_object_id bigint NOT NULL,
    "exists" boolean DEFAULT true NOT NULL
);


ALTER TABLE public.predecessor OWNER TO postgres;

--
-- Name: role; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE role (
    role_id integer NOT NULL,
    role_name character varying(255) NOT NULL
);


ALTER TABLE public.role OWNER TO postgres;

--
-- Name: type; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE type (
    type_id integer NOT NULL,
    type_name character varying(255) NOT NULL
);


ALTER TABLE public.type OWNER TO postgres;

--
-- Name: index_index_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE index_index_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.index_index_id_seq OWNER TO postgres;

--
-- Name: index_index_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE index_index_id_seq OWNED BY index.index_id;


--
-- Name: object_object_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE object_object_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.object_object_id_seq OWNER TO postgres;

--
-- Name: object_object_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE object_object_id_seq OWNED BY object.object_id;


--
-- Name: role_role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE role_role_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.role_role_id_seq OWNER TO postgres;

--
-- Name: role_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE role_role_id_seq OWNED BY role.role_id;


--
-- Name: type_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE type_type_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.type_type_id_seq OWNER TO postgres;

--
-- Name: type_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE type_type_id_seq OWNED BY type.type_id;


--
-- Name: index_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE index ALTER COLUMN index_id SET DEFAULT nextval('index_index_id_seq'::regclass);


--
-- Name: object_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE object ALTER COLUMN object_id SET DEFAULT nextval('object_object_id_seq'::regclass);


--
-- Name: role_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE role ALTER COLUMN role_id SET DEFAULT nextval('role_role_id_seq'::regclass);


--
-- Name: type_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE type ALTER COLUMN type_id SET DEFAULT nextval('type_type_id_seq'::regclass);


--
-- Name: index_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY index
    ADD CONSTRAINT index_id_pk PRIMARY KEY (index_id);


--
-- Name: index_name_idx; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY index
    ADD CONSTRAINT index_name_idx UNIQUE (index_name);


--
-- Name: object_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY object
    ADD CONSTRAINT object_id_pk PRIMARY KEY (object_id);


--
-- Name: role_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY role
    ADD CONSTRAINT role_id_pk PRIMARY KEY (role_id);


--
-- Name: role_name_idx; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY role
    ADD CONSTRAINT role_name_idx UNIQUE (role_name);


--
-- Name: type_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY type
    ADD CONSTRAINT type_id_pk PRIMARY KEY (type_id);


--
-- Name: type_name_idx; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY type
    ADD CONSTRAINT type_name_idx UNIQUE (type_name);


--
-- Name: index_date_object_value_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX index_date_object_value_idx ON index_date USING btree (object_id, value);


--
-- Name: predecessor_object_id_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX predecessor_object_id_idx ON predecessor USING btree (object_id);


--
-- Name: predecessor_predecessor_object_id_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX predecessor_predecessor_object_id_idx ON predecessor USING btree (predecessor_object_id);


--
-- Name: fK_object_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY index_date
    ADD CONSTRAINT "fK_object_id" FOREIGN KEY (object_id) REFERENCES object(object_id);


--
-- Name: fk_index_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY index_date
    ADD CONSTRAINT fk_index_id FOREIGN KEY (index_id) REFERENCES index(index_id);


--
-- Name: fk_object_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY predecessor
    ADD CONSTRAINT fk_object_id FOREIGN KEY (object_id) REFERENCES object(object_id);


--
-- Name: fk_predecessor_object_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY predecessor
    ADD CONSTRAINT fk_predecessor_object_id FOREIGN KEY (predecessor_object_id) REFERENCES object(object_id);


--
-- Name: fk_role_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY predecessor
    ADD CONSTRAINT fk_role_id FOREIGN KEY (role_id) REFERENCES role(role_id);


--
-- Name: type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY object
    ADD CONSTRAINT type_id_fk FOREIGN KEY (type_id) REFERENCES type(type_id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: index; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE index FROM PUBLIC;
REVOKE ALL ON TABLE index FROM postgres;
GRANT ALL ON TABLE index TO postgres;
GRANT ALL ON TABLE index TO PUBLIC;


--
-- Name: index_date; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE index_date FROM PUBLIC;
REVOKE ALL ON TABLE index_date FROM postgres;
GRANT ALL ON TABLE index_date TO postgres;
GRANT ALL ON TABLE index_date TO PUBLIC;


--
-- Name: object; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE object FROM PUBLIC;
REVOKE ALL ON TABLE object FROM postgres;
GRANT ALL ON TABLE object TO postgres;
GRANT ALL ON TABLE object TO PUBLIC;


--
-- Name: predecessor; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE predecessor FROM PUBLIC;
REVOKE ALL ON TABLE predecessor FROM postgres;
GRANT ALL ON TABLE predecessor TO postgres;
GRANT ALL ON TABLE predecessor TO PUBLIC;


--
-- Name: role; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE role FROM PUBLIC;
REVOKE ALL ON TABLE role FROM postgres;
GRANT ALL ON TABLE role TO postgres;
GRANT ALL ON TABLE role TO PUBLIC;


--
-- Name: type; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE type FROM PUBLIC;
REVOKE ALL ON TABLE type FROM postgres;
GRANT ALL ON TABLE type TO postgres;
GRANT ALL ON TABLE type TO PUBLIC;


--
-- Name: index_index_id_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON SEQUENCE index_index_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE index_index_id_seq FROM postgres;
GRANT ALL ON SEQUENCE index_index_id_seq TO postgres;
GRANT ALL ON SEQUENCE index_index_id_seq TO PUBLIC;


--
-- Name: object_object_id_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON SEQUENCE object_object_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE object_object_id_seq FROM postgres;
GRANT ALL ON SEQUENCE object_object_id_seq TO postgres;
GRANT ALL ON SEQUENCE object_object_id_seq TO PUBLIC;


--
-- Name: role_role_id_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON SEQUENCE role_role_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE role_role_id_seq FROM postgres;
GRANT ALL ON SEQUENCE role_role_id_seq TO postgres;
GRANT ALL ON SEQUENCE role_role_id_seq TO PUBLIC;


--
-- Name: type_type_id_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON SEQUENCE type_type_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE type_type_id_seq FROM postgres;
GRANT ALL ON SEQUENCE type_type_id_seq TO postgres;
GRANT ALL ON SEQUENCE type_type_id_seq TO PUBLIC;


--
-- PostgreSQL database dump complete
--

