using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;

namespace Mallardsoft.Tuple.UnitTest
{
    [TestFixture]
    public class TupleTest
    {
        [Test]
        public void TestPair()
        {
            Pair<int, string> pair = MakeTuple.From(2, "Hi");

            int m1;
            string m2;
            pair.Extract(out m1).Extract(out m2);

            Assert.AreEqual(2, m1);
            Assert.AreEqual("Hi", m2);
        }

        [Test]
        public void TestDecuple()
        {
            Decuple<int, double, string, int, double, string, float, long, bool, char> decuple = MakeTuple.From(1, 2.0, "three", 4, 5.0, "six", 7.0f, 8L, false, 't');

            int i;
            double d;
            decuple.Extract(out i).Extract(out d);
            Assert.AreEqual(1, i);
            Assert.AreEqual(2.0, d);
        }

        [Test]
        public void TestPairGet()
        {
            Pair<int, string> pair = MakeTuple.From(2, "Hi");

            int m1 = GetTuple.Member1(pair);
            string m2 = GetTuple.Member2(pair);

            Assert.AreEqual(2, m1);
            Assert.AreEqual("Hi", m2);
        }

        [Test]
        public void TestDecupleGet()
        {
            Decuple<int, double, string, int, double, string, float, long, bool, char> decuple = MakeTuple.From(1, 2.0, "three", 4, 5.0, "six", 7.0f, 8L, false, 't');

            int i = GetTuple.Member1(decuple);
            double d = GetTuple.Member2(decuple);
            char c = GetTuple.Member10(decuple);

            Assert.AreEqual(1, i);
            Assert.AreEqual(2.0, d);
            Assert.AreEqual('t', c);
        }

        [Test]
        public void TestApplyPair()
        {
            Pair<string, int> pair = MakeTuple.From("Number ", 6);

            string result = Function<string>.Apply(Append, pair);

            Assert.AreEqual("Number 6", result);
        }

        private string Append(string str, int n)
        {
            return new StringBuilder().Append(str).Append(n).ToString();
        }
    }
}
