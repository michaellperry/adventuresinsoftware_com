using System;
using System.Collections.Generic;
using System.Text;

namespace Mallardsoft.Tuple
{
    public class Triple<T1, T2, T3> : Tuple<T1, Tuple<T2, Tuple<T3, End>>>
        where T1 : IComparable<T1>
        where T2 : IComparable<T2>
        where T3 : IComparable<T3>
    {
        public Triple(T1 m1, T2 m2, T3 m3)
            : base(m1, MakeTuple.From(m2, m3))
        {
        }
    }
}
