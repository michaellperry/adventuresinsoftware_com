using System;
using System.Collections.Generic;
using System.Text;

namespace Mallardsoft.Tuple
{
    public static class Function<Return>
    {
        public delegate Return F1<T1>(T1 p1);
        public delegate Return F2<T1, T2>(T1 p1, T2 p2);
        public delegate Return F3<T1, T2, T3>(T1 p1, T2 p2, T3 p3);
        public delegate Return F4<T1, T2, T3, T4>(T1 p1, T2 p2, T3 p3, T4 p4);
        public delegate Return F5<T1, T2, T3, T4, T5>(T1 p1, T2 p2, T3 p3, T4 p4, T5 p5);
        public delegate Return F6<T1, T2, T3, T4, T5, T6>(T1 p1, T2 p2, T3 p3, T4 p4, T5 p5, T6 p6);
        public delegate Return F7<T1, T2, T3, T4, T5, T6, T7>(T1 p1, T2 p2, T3 p3, T4 p4, T5 p5, T6 p6, T7 p7);
        public delegate Return F8<T1, T2, T3, T4, T5, T6, T7, T8>(T1 p1, T2 p2, T3 p3, T4 p4, T5 p5, T6 p6, T7 p7, T8 p8);
        public delegate Return F9<T1, T2, T3, T4, T5, T6, T7, T8, T9>(T1 p1, T2 p2, T3 p3, T4 p4, T5 p5, T6 p6, T7 p7, T8 p8, T9 p9);
        public delegate Return F10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10>(T1 p1, T2 p2, T3 p3, T4 p4, T5 p5, T6 p6, T7 p7, T8 p8, T9 p9, T10 p10);

        public static Return Apply<T1>(F1<T1> f, Tuple<T1, End> tuple)
            where T1 : IComparable<T1>
        {
            return f(tuple._first);
        }

        public static Return Apply<T1, T2>(F2<T1, T2> f, Tuple<T1, Tuple<T2, End>> tuple)
            where T1 : IComparable<T1>
            where T2 : IComparable<T2>
        {
            return f(tuple._first, tuple._rest._first);
        }

        public static Return Apply<T1, T2, T3>(F3<T1, T2, T3> f, Tuple<T1, Tuple<T2, Tuple<T3, End>>> tuple)
            where T1 : IComparable<T1>
            where T2 : IComparable<T2>
            where T3 : IComparable<T3>
        {
            return f(tuple._first, tuple._rest._first, tuple._rest._rest._first);
        }

        public static Return Apply<T1, T2, T3, T4>(F4<T1, T2, T3, T4> f, Tuple<T1, Tuple<T2, Tuple<T3, Tuple<T4, End>>>> tuple)
            where T1 : IComparable<T1>
            where T2 : IComparable<T2>
            where T3 : IComparable<T3>
            where T4 : IComparable<T4>
        {
            return f(tuple._first, tuple._rest._first, tuple._rest._rest._first, tuple._rest._rest._rest._first);
        }

        public static Return Apply<T1, T2, T3, T4, T5>(F5<T1, T2, T3, T4, T5> f, Tuple<T1, Tuple<T2, Tuple<T3, Tuple<T4, Tuple<T5, End>>>>> tuple)
            where T1 : IComparable<T1>
            where T2 : IComparable<T2>
            where T3 : IComparable<T3>
            where T4 : IComparable<T4>
            where T5 : IComparable<T5>
        {
            return f(tuple._first, tuple._rest._first, tuple._rest._rest._first, tuple._rest._rest._rest._first, tuple._rest._rest._rest._rest._first);
        }

        public static Return Apply<T1, T2, T3, T4, T5, T6>(F6<T1, T2, T3, T4, T5, T6> f, Tuple<T1, Tuple<T2, Tuple<T3, Tuple<T4, Tuple<T5, Tuple<T6, End>>>>>> tuple)
            where T1 : IComparable<T1>
            where T2 : IComparable<T2>
            where T3 : IComparable<T3>
            where T4 : IComparable<T4>
            where T5 : IComparable<T5>
            where T6 : IComparable<T6>
        {
            return f(tuple._first, tuple._rest._first, tuple._rest._rest._first, tuple._rest._rest._rest._first, tuple._rest._rest._rest._rest._first, tuple._rest._rest._rest._rest._rest._first);
        }

        public static Return Apply<T1, T2, T3, T4, T5, T6, T7>(F7<T1, T2, T3, T4, T5, T6, T7> f, Tuple<T1, Tuple<T2, Tuple<T3, Tuple<T4, Tuple<T5, Tuple<T6, Tuple<T7, End>>>>>>> tuple)
            where T1 : IComparable<T1>
            where T2 : IComparable<T2>
            where T3 : IComparable<T3>
            where T4 : IComparable<T4>
            where T5 : IComparable<T5>
            where T6 : IComparable<T6>
            where T7 : IComparable<T7>
        {
            return f(tuple._first, tuple._rest._first, tuple._rest._rest._first, tuple._rest._rest._rest._first, tuple._rest._rest._rest._rest._first, tuple._rest._rest._rest._rest._rest._first, tuple._rest._rest._rest._rest._rest._rest._first);
        }

        public static Return Apply<T1, T2, T3, T4, T5, T6, T7, T8>(F8<T1, T2, T3, T4, T5, T6, T7, T8> f, Tuple<T1, Tuple<T2, Tuple<T3, Tuple<T4, Tuple<T5, Tuple<T6, Tuple<T7, Tuple<T8, End>>>>>>>> tuple)
            where T1 : IComparable<T1>
            where T2 : IComparable<T2>
            where T3 : IComparable<T3>
            where T4 : IComparable<T4>
            where T5 : IComparable<T5>
            where T6 : IComparable<T6>
            where T7 : IComparable<T7>
            where T8 : IComparable<T8>
        {
            return f(tuple._first, tuple._rest._first, tuple._rest._rest._first, tuple._rest._rest._rest._first, tuple._rest._rest._rest._rest._first, tuple._rest._rest._rest._rest._rest._first, tuple._rest._rest._rest._rest._rest._rest._first, tuple._rest._rest._rest._rest._rest._rest._rest._first);
        }

        public static Return Apply<T1, T2, T3, T4, T5, T6, T7, T8, T9>(F9<T1, T2, T3, T4, T5, T6, T7, T8, T9> f, Tuple<T1, Tuple<T2, Tuple<T3, Tuple<T4, Tuple<T5, Tuple<T6, Tuple<T7, Tuple<T8, Tuple<T9, End>>>>>>>>> tuple)
            where T1 : IComparable<T1>
            where T2 : IComparable<T2>
            where T3 : IComparable<T3>
            where T4 : IComparable<T4>
            where T5 : IComparable<T5>
            where T6 : IComparable<T6>
            where T7 : IComparable<T7>
            where T8 : IComparable<T8>
            where T9 : IComparable<T9>
        {
            return f(tuple._first, tuple._rest._first, tuple._rest._rest._first, tuple._rest._rest._rest._first, tuple._rest._rest._rest._rest._first, tuple._rest._rest._rest._rest._rest._first, tuple._rest._rest._rest._rest._rest._rest._first, tuple._rest._rest._rest._rest._rest._rest._rest._first, tuple._rest._rest._rest._rest._rest._rest._rest._rest._first);
        }

        public static Return Apply<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10>(F10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> f, Tuple<T1, Tuple<T2, Tuple<T3, Tuple<T4, Tuple<T5, Tuple<T6, Tuple<T7, Tuple<T8, Tuple<T9, Tuple<T10, End>>>>>>>>>> tuple)
            where T1 : IComparable<T1>
            where T2 : IComparable<T2>
            where T3 : IComparable<T3>
            where T4 : IComparable<T4>
            where T5 : IComparable<T5>
            where T6 : IComparable<T6>
            where T7 : IComparable<T7>
            where T8 : IComparable<T8>
            where T9 : IComparable<T9>
            where T10 : IComparable<T10>
        {
            return f(tuple._first, tuple._rest._first, tuple._rest._rest._first, tuple._rest._rest._rest._first, tuple._rest._rest._rest._rest._first, tuple._rest._rest._rest._rest._rest._first, tuple._rest._rest._rest._rest._rest._rest._first, tuple._rest._rest._rest._rest._rest._rest._rest._first, tuple._rest._rest._rest._rest._rest._rest._rest._rest._first, tuple._rest._rest._rest._rest._rest._rest._rest._rest._rest._first);
        }
    }
}
