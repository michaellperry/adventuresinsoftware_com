using System;
using System.Collections.Generic;
using System.Text;

namespace Mallardsoft.Tuple
{
    public interface ISeparatedAppender
    {
        void AppendString(StringBuilder result, string separator);
    }
}
