using System;
using System.Collections.Generic;
using System.Text;

namespace Mallardsoft.Tuple
{
    public class Tuple<First, Rest> : ISeparatedAppender, IComparable<Tuple<First, Rest>>
        where First : IComparable<First>
        where Rest : ISeparatedAppender, IComparable<Rest>
    {
        internal First _first;
        internal Rest _rest;

        internal Tuple(First first, Rest rest)
        {
            _first = first;
            _rest = rest;
        }

        public Tuple<T, Tuple<First, Rest>> prepend<T>(T m) where T : IComparable<T>
        {
            return new Tuple<T, Tuple<First, Rest>>(m, this);
        }

        public Rest Extract(out First v)
        {
            v = _first;
            return _rest;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
                return false;
            if (Object.ReferenceEquals(obj, this))
                return true;
            if (!(obj is Tuple<First, Rest>))
                return false;
            Tuple<First, Rest> that = (Tuple<First, Rest>)obj;
            return
                Object.Equals(this._first, that._first) &&
                Object.Equals(this._rest, that._rest);
        }

        public override int GetHashCode()
        {
            return (_first == null ? 0 : _first.GetHashCode()) + _rest.GetHashCode() * 37;
        }

        public override string ToString()
        {
            return ToString("(", ", ", ")");
        }

        public string ToString(string open, string separator, string close)
        {
            StringBuilder result = new StringBuilder();
            result.Append(open).Append(_first);
            _rest.AppendString(result, separator);
            return result.Append(close).ToString();
        }

        public void AppendString(StringBuilder result, string separator)
        {
            result.Append(separator).Append(_first);
            _rest.AppendString(result, separator);
        }

        public int CompareTo(Tuple<First, Rest> other)
        {
            int compare =
                _first == null ?
                    other._first == null ? 0 : -other._first.CompareTo(_first) :
                    _first.CompareTo(other._first);
            if (compare != 0)
                return compare;
            else
                return _rest.CompareTo(other._rest);
        }
    }
}
