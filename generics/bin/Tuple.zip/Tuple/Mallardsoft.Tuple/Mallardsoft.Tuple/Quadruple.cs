using System;
using System.Collections.Generic;
using System.Text;

namespace Mallardsoft.Tuple
{
    public class Quadruple<T1, T2, T3, T4> : Tuple<T1, Tuple<T2, Tuple<T3, Tuple<T4, End>>>>
        where T1 : IComparable<T1>
        where T2 : IComparable<T2>
        where T3 : IComparable<T3>
        where T4 : IComparable<T4>
    {
        public Quadruple(T1 m1, T2 m2, T3 m3, T4 m4)
            : base(m1, MakeTuple.From(m2, m3, m4))
        {
        }
    }
}
