using System;
using System.Collections.Generic;
using System.Text;

namespace Mallardsoft.Tuple
{
    public class Quintuple<T1, T2, T3, T4, T5> : Tuple<T1, Tuple<T2, Tuple<T3, Tuple<T4, Tuple<T5, End>>>>>
        where T1 : IComparable<T1>
        where T2 : IComparable<T2>
        where T3 : IComparable<T3>
        where T4 : IComparable<T4>
        where T5 : IComparable<T5>
    {
        public Quintuple(T1 m1, T2 m2, T3 m3, T4 m4, T5 m5)
            : base(m1, MakeTuple.From(m2, m3, m4, m5))
        {
        }
    }
}
