using System;
using System.Collections.Generic;
using System.Text;

namespace Mallardsoft.Tuple
{
    public static class GetTuple
    {
        public static T1 Member1<T1, Rest>(Tuple<T1, Rest> tuple)
            where T1 : IComparable<T1>
            where Rest : ISeparatedAppender, IComparable<Rest>
        {
            return tuple._first;
        }

        public static T2 Member2<T1, T2, Rest>(Tuple<T1, Tuple<T2, Rest>> tuple)
            where T1 : IComparable<T1>
            where T2 : IComparable<T2>
            where Rest : ISeparatedAppender, IComparable<Rest>
        {
            return tuple._rest._first;
        }

        public static T3 Member3<T1, T2, T3, Rest>(Tuple<T1, Tuple<T2, Tuple<T3, Rest>>> tuple)
            where T1 : IComparable<T1>
            where T2 : IComparable<T2>
            where T3 : IComparable<T3>
            where Rest : ISeparatedAppender, IComparable<Rest>
        {
            return tuple._rest._rest._first;
        }

        public static T4 Member4<T1, T2, T3, T4, Rest>(Tuple<T1, Tuple<T2, Tuple<T3, Tuple<T4, Rest>>>> tuple)
            where T1 : IComparable<T1>
            where T2 : IComparable<T2>
            where T3 : IComparable<T3>
            where T4 : IComparable<T4>
            where Rest : ISeparatedAppender, IComparable<Rest>
        {
            return tuple._rest._rest._rest._first;
        }

        public static T5 Member5<T1, T2, T3, T4, T5, Rest>(Tuple<T1, Tuple<T2, Tuple<T3, Tuple<T4, Tuple<T5, Rest>>>>> tuple)
            where T1 : IComparable<T1>
            where T2 : IComparable<T2>
            where T3 : IComparable<T3>
            where T4 : IComparable<T4>
            where T5 : IComparable<T5>
            where Rest : ISeparatedAppender, IComparable<Rest>
        {
            return tuple._rest._rest._rest._rest._first;
        }

        public static T6 Member6<T1, T2, T3, T4, T5, T6, Rest>(Tuple<T1, Tuple<T2, Tuple<T3, Tuple<T4, Tuple<T5, Tuple<T6, Rest>>>>>> tuple)
            where T1 : IComparable<T1>
            where T2 : IComparable<T2>
            where T3 : IComparable<T3>
            where T4 : IComparable<T4>
            where T5 : IComparable<T5>
            where T6 : IComparable<T6>
            where Rest : ISeparatedAppender, IComparable<Rest>
        {
            return tuple._rest._rest._rest._rest._rest._first;
        }

        public static T7 Member7<T1, T2, T3, T4, T5, T6, T7, Rest>(Tuple<T1, Tuple<T2, Tuple<T3, Tuple<T4, Tuple<T5, Tuple<T6, Tuple<T7, Rest>>>>>>> tuple)
            where T1 : IComparable<T1>
            where T2 : IComparable<T2>
            where T3 : IComparable<T3>
            where T4 : IComparable<T4>
            where T5 : IComparable<T5>
            where T6 : IComparable<T6>
            where T7 : IComparable<T7>
            where Rest : ISeparatedAppender, IComparable<Rest>
        {
            return tuple._rest._rest._rest._rest._rest._rest._first;
        }

        public static T8 Member8<T1, T2, T3, T4, T5, T6, T7, T8, Rest>(Tuple<T1, Tuple<T2, Tuple<T3, Tuple<T4, Tuple<T5, Tuple<T6, Tuple<T7, Tuple<T8, Rest>>>>>>>> tuple)
            where T1 : IComparable<T1>
            where T2 : IComparable<T2>
            where T3 : IComparable<T3>
            where T4 : IComparable<T4>
            where T5 : IComparable<T5>
            where T6 : IComparable<T6>
            where T7 : IComparable<T7>
            where T8 : IComparable<T8>
            where Rest : ISeparatedAppender, IComparable<Rest>
        {
            return tuple._rest._rest._rest._rest._rest._rest._rest._first;
        }

        public static T9 Member9<T1, T2, T3, T4, T5, T6, T7, T8, T9, Rest>(Tuple<T1, Tuple<T2, Tuple<T3, Tuple<T4, Tuple<T5, Tuple<T6, Tuple<T7, Tuple<T8, Tuple<T9, Rest>>>>>>>>> tuple)
            where T1 : IComparable<T1>
            where T2 : IComparable<T2>
            where T3 : IComparable<T3>
            where T4 : IComparable<T4>
            where T5 : IComparable<T5>
            where T6 : IComparable<T6>
            where T7 : IComparable<T7>
            where T8 : IComparable<T8>
            where T9 : IComparable<T9>
            where Rest : ISeparatedAppender, IComparable<Rest>
        {
            return tuple._rest._rest._rest._rest._rest._rest._rest._rest._first;
        }

        public static T10 Member10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, Rest>(Tuple<T1, Tuple<T2, Tuple<T3, Tuple<T4, Tuple<T5, Tuple<T6, Tuple<T7, Tuple<T8, Tuple<T9, Tuple<T10, Rest>>>>>>>>>> tuple)
            where T1 : IComparable<T1>
            where T2 : IComparable<T2>
            where T3 : IComparable<T3>
            where T4 : IComparable<T4>
            where T5 : IComparable<T5>
            where T6 : IComparable<T6>
            where T7 : IComparable<T7>
            where T8 : IComparable<T8>
            where T9 : IComparable<T9>
            where T10 : IComparable<T10>
            where Rest : ISeparatedAppender, IComparable<Rest>
        {
            return tuple._rest._rest._rest._rest._rest._rest._rest._rest._rest._first;
        }
    }
}
