using System;
using System.Collections.Generic;
using System.Text;

namespace Mallardsoft.Tuple
{
    public class Pair<T1, T2> : Tuple<T1, Tuple<T2, End>>
        where T1 : IComparable<T1>
        where T2 : IComparable<T2>
    {
        public Pair(T1 m1, T2 m2)
            : base(m1, MakeTuple.From(m2))
        {
        }
    }
}
