using System;
using System.Collections.Generic;
using System.Text;

namespace Mallardsoft.Tuple
{
    public class Version : Quadruple<int, int, int, int>
    {
        public Version(int major, int minor, int release, int qfe)
            : base(major, minor, release, qfe)
        {
        }
    }
}
