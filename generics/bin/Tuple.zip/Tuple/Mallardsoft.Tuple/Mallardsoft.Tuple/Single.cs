using System;
using System.Collections.Generic;
using System.Text;

namespace Mallardsoft.Tuple
{
    public class Single<T1> : Tuple<T1, End>
        where T1 : IComparable<T1>
    {
        public Single(T1 m1)
            : base(m1, End.Instance)
        {
        }
    }
}
