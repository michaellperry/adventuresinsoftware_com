using System;
using System.Collections.Generic;
using System.Text;

namespace Mallardsoft.Tuple
{
    public static class MakeTuple
    {
        public static Single<T1> From<T1>(T1 m1)
            where T1 : IComparable<T1>
        {
            return new Single<T1>(m1);
        }

        public static Pair<T1, T2> From<T1, T2>(T1 m1, T2 m2)
            where T1 : IComparable<T1>
            where T2 : IComparable<T2>
        {
            return new Pair<T1, T2>(m1, m2);
        }

        public static Triple<T1, T2, T3> From<T1, T2, T3>(T1 m1, T2 m2, T3 m3)
            where T1 : IComparable<T1>
            where T2 : IComparable<T2>
            where T3 : IComparable<T3>
        {
            return new Triple<T1, T2, T3>(m1, m2, m3);
        }

        public static Quadruple<T1, T2, T3, T4> From<T1, T2, T3, T4>(T1 m1, T2 m2, T3 m3, T4 m4)
            where T1 : IComparable<T1>
            where T2 : IComparable<T2>
            where T3 : IComparable<T3>
            where T4 : IComparable<T4>
        {
            return new Quadruple<T1, T2, T3, T4>(m1, m2, m3, m4);
        }

        public static Quintuple<T1, T2, T3, T4, T5> From<T1, T2, T3, T4, T5>(T1 m1, T2 m2, T3 m3, T4 m4, T5 m5)
            where T1 : IComparable<T1>
            where T2 : IComparable<T2>
            where T3 : IComparable<T3>
            where T4 : IComparable<T4>
            where T5 : IComparable<T5>
        {
            return new Quintuple<T1, T2, T3, T4, T5>(m1, m2, m3, m4, m5);
        }

        public static Sextuple<T1, T2, T3, T4, T5, T6> From<T1, T2, T3, T4, T5, T6>(T1 m1, T2 m2, T3 m3, T4 m4, T5 m5, T6 m6)
            where T1 : IComparable<T1>
            where T2 : IComparable<T2>
            where T3 : IComparable<T3>
            where T4 : IComparable<T4>
            where T5 : IComparable<T5>
            where T6 : IComparable<T6>
        {
            return new Sextuple<T1, T2, T3, T4, T5, T6>(m1, m2, m3, m4, m5, m6);
        }

        public static Septuple<T1, T2, T3, T4, T5, T6, T7> From<T1, T2, T3, T4, T5, T6, T7>(T1 m1, T2 m2, T3 m3, T4 m4, T5 m5, T6 m6, T7 m7)
            where T1 : IComparable<T1>
            where T2 : IComparable<T2>
            where T3 : IComparable<T3>
            where T4 : IComparable<T4>
            where T5 : IComparable<T5>
            where T6 : IComparable<T6>
            where T7 : IComparable<T7>
        {
            return new Septuple<T1, T2, T3, T4, T5, T6, T7>(m1, m2, m3, m4, m5, m6, m7);
        }

        public static Octuple<T1, T2, T3, T4, T5, T6, T7, T8> From<T1, T2, T3, T4, T5, T6, T7, T8>(T1 m1, T2 m2, T3 m3, T4 m4, T5 m5, T6 m6, T7 m7, T8 m8)
            where T1 : IComparable<T1>
            where T2 : IComparable<T2>
            where T3 : IComparable<T3>
            where T4 : IComparable<T4>
            where T5 : IComparable<T5>
            where T6 : IComparable<T6>
            where T7 : IComparable<T7>
            where T8 : IComparable<T8>
        {
            return new Octuple<T1, T2, T3, T4, T5, T6, T7, T8>(m1, m2, m3, m4, m5, m6, m7, m8);
        }

        public static Nonuple<T1, T2, T3, T4, T5, T6, T7, T8, T9> From<T1, T2, T3, T4, T5, T6, T7, T8, T9>(T1 m1, T2 m2, T3 m3, T4 m4, T5 m5, T6 m6, T7 m7, T8 m8, T9 m9)
            where T1 : IComparable<T1>
            where T2 : IComparable<T2>
            where T3 : IComparable<T3>
            where T4 : IComparable<T4>
            where T5 : IComparable<T5>
            where T6 : IComparable<T6>
            where T7 : IComparable<T7>
            where T8 : IComparable<T8>
            where T9 : IComparable<T9>
        {
            return new Nonuple<T1, T2, T3, T4, T5, T6, T7, T8, T9>(m1, m2, m3, m4, m5, m6, m7, m8, m9);
        }

        public static Decuple<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> From<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10>(T1 m1, T2 m2, T3 m3, T4 m4, T5 m5, T6 m6, T7 m7, T8 m8, T9 m9, T10 m10)
            where T1 : IComparable<T1>
            where T2 : IComparable<T2>
            where T3 : IComparable<T3>
            where T4 : IComparable<T4>
            where T5 : IComparable<T5>
            where T6 : IComparable<T6>
            where T7 : IComparable<T7>
            where T8 : IComparable<T8>
            where T9 : IComparable<T9>
            where T10 : IComparable<T10>
        {
            return new Decuple<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10>(m1, m2, m3, m4, m5, m6, m7, m8, m9, m10);
        }
    }
}
