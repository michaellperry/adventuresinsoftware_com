using System;
using System.Collections.Generic;
using System.Text;

namespace Mallardsoft.Tuple
{
    public class End : ISeparatedAppender, IComparable<End>
    {
        private static End _instance = new End();

        private End() { }

        public static End Instance
        {
            get { return _instance; }
        }

        public void AppendString(StringBuilder result, string separator)
        {
        }

        public int CompareTo(End other)
        {
            return 0;
        }
    }
}
