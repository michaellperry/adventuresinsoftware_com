using System;
using System.Collections.Generic;
using System.Text;

namespace Mallardsoft.Tuple
{
    public class Nonuple<T1, T2, T3, T4, T5, T6, T7, T8, T9> : Tuple<T1, Tuple<T2, Tuple<T3, Tuple<T4, Tuple<T5, Tuple<T6, Tuple<T7, Tuple<T8, Tuple<T9, End>>>>>>>>>
        where T1 : IComparable<T1>
        where T2 : IComparable<T2>
        where T3 : IComparable<T3>
        where T4 : IComparable<T4>
        where T5 : IComparable<T5>
        where T6 : IComparable<T6>
        where T7 : IComparable<T7>
        where T8 : IComparable<T8>
        where T9 : IComparable<T9>
    {
        public Nonuple(T1 m1, T2 m2, T3 m3, T4 m4, T5 m5, T6 m6, T7 m7, T8 m8, T9 m9)
            : base(m1, MakeTuple.From(m2, m3, m4, m5, m6, m7, m8, m9))
        {
        }
    }
}
