using System;
using System.Collections.Generic;
using System.Text;

namespace GenericsCS.Policy
{
    public class LIFO<T> : IOrderingPolicy<T>
    {
        private Stack<T> _stack = new Stack<T>();

        public void PutItem(T value)
        {
            _stack.Push(value);
        }

        public T GetItem()
        {
            return _stack.Pop();
        }
    }
}
