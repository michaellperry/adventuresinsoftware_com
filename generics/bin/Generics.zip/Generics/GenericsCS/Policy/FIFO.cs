using System;
using System.Collections.Generic;
using System.Text;

namespace GenericsCS.Policy
{
    public class FIFO<T> : IOrderingPolicy<T>
    {
        private Queue<T> _queue = new Queue<T>();

        public void PutItem(T value)
        {
            _queue.Enqueue(value);
        }

        public T GetItem()
        {
            return _queue.Dequeue();
        }
    }
}
