using System;
using System.Collections.Generic;
using System.Text;

namespace GenericsCS.Policy
{
    public interface IWorkItem
    {
        void DoWork();
    }
}
