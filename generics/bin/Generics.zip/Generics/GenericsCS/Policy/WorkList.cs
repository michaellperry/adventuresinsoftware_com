using System;
using System.Collections.Generic;
using System.Text;

namespace GenericsCS.Policy
{
    public class WorkList<T, OrderingPolicy>
        where OrderingPolicy : IOrderingPolicy<T>, new()
        where T : IWorkItem
    {
        private OrderingPolicy _orderingPolicy =
            new OrderingPolicy();

        public void AddWork(T item)
        {
            _orderingPolicy.PutItem(item);
        }

        public void Work()
        {
            T item = _orderingPolicy.GetItem();
            item.DoWork();
        }
    }
}
