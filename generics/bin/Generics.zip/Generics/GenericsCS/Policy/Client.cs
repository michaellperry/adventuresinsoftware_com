using System;
using System.Collections.Generic;
using System.Text;

namespace GenericsCS.Policy
{
    public class Client
    {
        public class WorkItem : IWorkItem
        {
            public void DoWork()
            {
            }
        }

        public static void UseWorkList()
        {
            WorkList<WorkItem, FIFO<WorkItem>> workList =
                new WorkList<WorkItem, FIFO<WorkItem>>();
            workList.AddWork(new WorkItem());
            workList.Work();
        }
    }
}
