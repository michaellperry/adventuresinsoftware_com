using System;
using System.Collections.Generic;
using System.Text;

namespace GenericsCS.Syntax
{
    class Client
    {
        public static void UseGenericClass()
        {
            int l;
            l = new MyGenericClass<int>()
                .Method();
            l = new MyGenericClass<String>()
                .Method().Length;
            l = ClassWithGenericMethod
                .Method("Hello").Length;
        }
    }
}
