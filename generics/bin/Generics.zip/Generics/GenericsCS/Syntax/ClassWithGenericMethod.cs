using System;
using System.Collections.Generic;
using System.Text;

namespace GenericsCS.Syntax
{
    class ClassWithGenericMethod
    {
        public static T Method<T>(T value)
        {
            return value;
        }
    }
}
