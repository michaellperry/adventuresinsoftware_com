using System;
using System.Collections.Generic;
using System.Text;

namespace GenericsCS.Syntax
{
    class MyGenericClass<T>
    {
        private T _member;

        public T Method()
        {
            return default(T);
        }
    }
}
