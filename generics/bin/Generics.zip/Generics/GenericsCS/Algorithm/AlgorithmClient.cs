using System;
using System.Collections.Generic;
using System.Text;

namespace GenericsCS.Algorithm
{
    public class AlgorithmClient
    {
        public static void SortNames()
        {
            List<PersonName> phoneBook =
                new List<PersonName>();
            phoneBook.Add(new PersonName
                ("Michael", "Perry"));
            phoneBook.Add(new PersonName
                ("Jenny", "Perry"));
            phoneBook.Add(new PersonName
                ("Chuck", "Jazdzewski"));

            phoneBook.Sort(
                new PhoneBookComparer());
        }

        public static void SortBackward()
        {
            List<PersonName> phoneBook =
                new List<PersonName>();
            phoneBook.Add(new PersonName
                ("Michael", "Perry"));
            phoneBook.Add(new PersonName
                ("Jenny", "Perry"));
            phoneBook.Add(new PersonName
                ("Chuck", "Jazdzewski"));

            phoneBook.Sort(
                new ReverseComparer<PersonName>(
                    new PhoneBookComparer()));
        }

        public static void SortBackwardAuto()
        {
            List<PersonName> phoneBook =
                new List<PersonName>();
            phoneBook.Add(new PersonName
                ("Michael", "Perry"));
            phoneBook.Add(new PersonName
                ("Jenny", "Perry"));
            phoneBook.Add(new PersonName
                ("Chuck", "Jazdzewski"));

            phoneBook.Sort(
                ComparerHelper.Reverse(
                    new PhoneBookComparer()));
        }
    }
}
