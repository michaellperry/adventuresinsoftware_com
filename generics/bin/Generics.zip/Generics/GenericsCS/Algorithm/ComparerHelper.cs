using System;
using System.Collections.Generic;
using System.Text;

namespace GenericsCS.Algorithm
{
    public class ComparerHelper
    {
        public static IComparer<T>
            Reverse<T>(IComparer<T> comparer)
        {
            return new ReverseComparer<T>
                (comparer);
        }
    }
}
