using System;
using System.Collections.Generic;
using System.Text;

namespace GenericsCS.Algorithm
{
    public class PersonName
    {
        private string _first;
        private string _last;

        public PersonName(string first, string last)
        {
            _first = first;
            _last = last;
        }

        public string First
        {
            get { return _first; }
        }

        public string Last
        {
            get { return _last; }
        }
    }
}
