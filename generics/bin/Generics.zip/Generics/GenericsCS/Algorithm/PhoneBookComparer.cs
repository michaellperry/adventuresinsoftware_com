using System;
using System.Collections.Generic;
using System.Text;

namespace GenericsCS.Algorithm
{
    public class PhoneBookComparer :
        IComparer<PersonName>
    {
        public int Compare
            (PersonName x, PersonName y)
        {
            int result = string.Compare
                (x.Last, y.Last, true);
            if (result != 0)
                return result;
            else
                return string.Compare
                    (x.First, y.First, true);
        }
    }
}
