using System;
using System.Collections.Generic;
using System.Text;

namespace GenericsCS.Algorithm
{
    public class ReverseComparer<T> :
        IComparer<T>
    {
        private IComparer<T> _comparer;

        public ReverseComparer(
            IComparer<T> comparer)
        {
            _comparer = comparer;
        }

        public int Compare(T x, T y)
        {
            return _comparer.Compare(y, x);
        }
    }
}
