using System;
using System.Collections.Generic;
using System.Text;

namespace GenericsCS.Strategy
{
    public class MyLockableObject<LockingStrategy>
        where LockingStrategy : ILockingStrategy, new()
    {
        private LockingStrategy _lockingStrategy =
            new LockingStrategy();

        public void BeginUse()
        {
            _lockingStrategy.Lock();
        }

        public void EndUse()
        {
            _lockingStrategy.Unlock();
        }
    }
}
