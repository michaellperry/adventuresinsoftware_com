using System;
using System.Collections.Generic;
using System.Text;

namespace GenericsCS.Strategy
{
    public class Client
    {
        public void UseLockableObject()
        {
            MyLockableObject<SimpleLock> o =
                    new MyLockableObject<SimpleLock>();
            o.BeginUse();
            o.EndUse();
        }
    }
}
