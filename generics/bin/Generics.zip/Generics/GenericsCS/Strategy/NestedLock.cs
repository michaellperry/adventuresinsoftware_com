using System;
using System.Collections.Generic;
using System.Text;

namespace GenericsCS.Strategy
{
    public class NestedLock : ILockingStrategy
    {
        private int _depth = 0;

        public void Lock()
        {
            ++_depth;
        }

        public bool Unlock()
        {
            bool result = true;
            if (_depth > 0)
            {
                result = false;
                --_depth;
            }
            return result;
        }

        public bool Unlocked
        {
            get { return _depth == 0; }
        }
    }
}
