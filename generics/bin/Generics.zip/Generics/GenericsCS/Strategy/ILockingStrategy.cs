using System;
using System.Collections.Generic;
using System.Text;

namespace GenericsCS.Strategy
{
    public interface ILockingStrategy
    {
        void Lock();
        bool Unlock();
        bool Unlocked { get; }
    }
}
