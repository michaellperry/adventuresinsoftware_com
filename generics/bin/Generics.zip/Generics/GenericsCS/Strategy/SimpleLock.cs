using System;
using System.Collections.Generic;
using System.Text;

namespace GenericsCS.Strategy
{
    public class SimpleLock : ILockingStrategy
    {
        private bool _unlocked = true;

        public void Lock()
        {
            _unlocked = true;
        }

        public bool Unlock()
        {
            bool result = _unlocked;
            _unlocked = true;
            return result;
        }

        public bool Unlocked
        {
            get { return _unlocked; }
        }
    }
}
