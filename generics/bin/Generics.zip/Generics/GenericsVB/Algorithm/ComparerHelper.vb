Public Class ComparerHelper

    Public Shared Function Reverse(Of T) _
        (ByVal comparer As IComparer(Of T)) _
        As IComparer(Of T)

        Return New ReverseComparer(Of T) _
            (comparer)
    End Function

End Class
