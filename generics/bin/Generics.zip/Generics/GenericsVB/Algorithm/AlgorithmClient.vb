Public Class AlgorithmClient

    Public Shared Sub SortNames()
        Dim phoneBook As New List(Of PersonName)
        phoneBook.Add( _
            New PersonName("Michael", "Perry"))
        phoneBook.Add( _
            New PersonName("Jenny", "Perry"))
        phoneBook.Add( _
            New PersonName("Chuck", "Jazdzewski"))

        phoneBook.Sort( _
            New PhoneBookComparer)
    End Sub

    Public Shared Sub SortBackward()
        Dim phoneBook As New List(Of PersonName)
        phoneBook.Add( _
            New PersonName("Michael", "Perry"))
        phoneBook.Add( _
            New PersonName("Jenny", "Perry"))
        phoneBook.Add( _
            New PersonName("Chuck", "Jazdzewski"))

        phoneBook.Sort( _
            New ReverseComparer(Of PersonName)( _
                New PhoneBookComparer))
    End Sub

    Public Shared Sub SortBackwardAuto()
        Dim phoneBook As New List(Of PersonName)
        phoneBook.Add( _
            New PersonName("Michael", "Perry"))
        phoneBook.Add( _
            New PersonName("Jenny", "Perry"))
        phoneBook.Add( _
            New PersonName("Chuck", "Jazdzewski"))

        phoneBook.Sort( _
            ComparerHelper.Reverse( _
                New PhoneBookComparer))
    End Sub

End Class
