Public Class ReverseComparer(Of T)
    Implements IComparer(Of T)

    Private _comparer As IComparer(Of T)

    Public Sub New(ByVal comparer As _
        IComparer(Of T))

        _comparer = comparer
    End Sub

    Public Function Compare( _
        ByVal x As T, ByVal y As T) As Integer _
        Implements IComparer(Of T).Compare

        Return _comparer.Compare(y, x)
    End Function
End Class
