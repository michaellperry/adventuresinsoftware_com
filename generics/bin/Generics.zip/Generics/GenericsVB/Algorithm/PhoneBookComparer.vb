Public Class PhoneBookComparer
    Implements IComparer(Of PersonName)

    Public Function Compare _
        (ByVal x As PersonName, _
        ByVal y As PersonName) As Integer _
        Implements IComparer(Of PersonName) _
            .Compare

        Dim result As Integer
        result = String.Compare _
            (x.Last, y.Last, True)
        If result <> 0 Then
            Return result
        Else
            Return String.Compare _
                (x.First, y.First, True)
        End If
    End Function
End Class
