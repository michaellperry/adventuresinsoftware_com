Public Class PersonName

    Private _first As String
    Private _last As String

    Public Sub New(ByVal first As String, ByVal last As String)
        _first = first
        _last = last
    End Sub

    Public ReadOnly Property First() As String
        Get
            Return _first
        End Get
    End Property

    Public ReadOnly Property Last() As String
        Get
            Return _last
        End Get
    End Property

End Class
