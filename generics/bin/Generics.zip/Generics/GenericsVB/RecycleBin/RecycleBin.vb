Public Class RecycleBin(Of T As IDisposable)
    Implements IDisposable

    Private _recyclableObjects As Hashtable

    Public Sub New()

    End Sub

    Public Sub New(ByVal objects As System.Collections.IEnumerable)
        For Each recyclableObject As Object In objects
            _recyclableObjects.Add(recyclableObject, recyclableObject)
        Next
    End Sub

    Public Sub AddObject(ByVal recyclableObject As Object)
        _recyclableObjects.Add(recyclableObject, recyclableObject)
    End Sub

    Public Function Extract(ByVal prototype As T) As T
        ' See if a matching object is already in the recycle bin.
        Dim match As Object

        match = _recyclableObjects(prototype)
        If (match Is Nothing) Then
            ' No, so use the prototype.
            Return match
        Else
            ' Yes, so extract it.
            prototype.Dispose()
            _recyclableObjects.Remove(match)
            Return match
        End If
    End Function

    Public Sub Dispose() Implements IDisposable.Dispose
        For Each recyclableObject As IDisposable In _recyclableObjects
            recyclableObject.Dispose()
        Next
    End Sub

End Class
