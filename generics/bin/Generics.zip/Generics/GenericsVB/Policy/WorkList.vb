Public Class WorkList(Of T As IWorkItem, _
    OrderingPolicy As {IOrderingPolicy(Of T), New})

    Private _orderingPolicy As New OrderingPolicy()

    Public Sub AddWork(ByVal item As T)
        _orderingPolicy.PutItem(item)
    End Sub

    Public Sub Work()
        Dim item As T
        item = _orderingPolicy.GetItem
        item.DoWork()
    End Sub

End Class
