Public Class FIFO(Of T)
    Implements IOrderingPolicy(Of T)

    Private _queue As New Queue(Of T)

    Public Sub PutItem(ByVal item As T) _
        Implements IOrderingPolicy(Of T).PutItem
        _queue.Enqueue(item)
    End Sub

    Public Function GetItem() As T _
        Implements IOrderingPolicy(Of T).GetItem
        Return _queue.Dequeue()
    End Function

End Class
