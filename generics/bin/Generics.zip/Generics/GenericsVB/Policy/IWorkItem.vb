Public Interface IWorkItem

    Sub DoWork()

End Interface
