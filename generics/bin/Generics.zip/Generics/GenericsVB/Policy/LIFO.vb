Public Class LIFO(Of T)
    Implements IOrderingPolicy(Of T)

    Private _stack As New Stack(Of T)

    Public Sub PutItem(ByVal item As T) Implements IOrderingPolicy(Of T).PutItem
        _stack.Push(item)
    End Sub

    Public Function GetItem() As T Implements IOrderingPolicy(Of T).GetItem
        Return _stack.Pop()
    End Function

End Class
