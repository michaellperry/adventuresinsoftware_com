Public Class PolicyClient

    Class WorkItem
        Implements IWorkItem

        Public Sub DoWork() Implements IWorkItem.DoWork

        End Sub
    End Class

    Public Shared Sub UseWorkList()
        Dim workList As New WorkList(Of WorkItem, FIFO(Of WorkItem))
        workList.AddWork(New WorkItem)
        workList.Work()
    End Sub

End Class
