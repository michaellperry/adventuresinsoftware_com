Public Interface IOrderingPolicy(Of T)

    Sub PutItem(ByVal value As T)
    Function GetItem() As T

End Interface
