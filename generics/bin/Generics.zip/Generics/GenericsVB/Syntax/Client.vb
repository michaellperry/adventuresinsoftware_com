Public Class Client

    Public Shared Sub UseGenericClass()
        Dim l As Integer
        l = New MyGenericClass(Of Integer)() _
            .Method
        l = New MyGenericClass(Of String)() _
            .Method.Length
        l = ClassWithGenericMethod _
            .Method("Hello").Length
    End Sub
End Class
