Public Class ClassWithGenericMethod

    Public Shared Function Method(Of T)(ByVal value As T) As T
        Return value
    End Function

End Class
