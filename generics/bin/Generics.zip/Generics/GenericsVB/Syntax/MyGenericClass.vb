Public Class MyGenericClass(Of T)

    Private _member As T

    Public Function Method() As T
        Return Nothing
    End Function

End Class
