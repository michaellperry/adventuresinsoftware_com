Public Interface ILockingStrategy

    Sub Lock()
    Function Unlock() As Boolean
    ReadOnly Property Unlocked() As Boolean

End Interface
