Public Class StrategyClient

    Public Sub UseLockableObject()
        Dim o As New MyLockableObject(Of SimpleLock)
        o.BeginUse()
        o.EndUse()
    End Sub

End Class
