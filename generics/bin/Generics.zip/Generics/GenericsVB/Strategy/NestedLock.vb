Public Class NestedLock
    Implements ILockingStrategy

    Private _depth As Integer

    Public Sub New()
        _depth = 0
    End Sub

    Public Sub Lock() Implements ILockingStrategy.Lock
        _depth = _depth + 1
    End Sub

    Public Function Unlock() As Boolean Implements ILockingStrategy.Unlock
        Dim result As Boolean
        result = True
        If _depth > 1 Then
            result = False
            _depth = _depth - 1
        End If
        Return result
    End Function

    Public ReadOnly Property Unlocked() As Boolean Implements ILockingStrategy.Unlocked
        Get
            Return _depth = 0
        End Get
    End Property

End Class
