Public Class SimpleLock
    Implements ILockingStrategy

    Private _unlocked As Boolean

    Public Sub New()
        _unlocked = True
    End Sub

    Public Sub Lock() Implements ILockingStrategy.Lock
        _unlocked = False
    End Sub

    Public Function Unlock() As Boolean Implements ILockingStrategy.Unlock
        Dim result As Boolean
        result = _unlocked
        _unlocked = True
        Return result
    End Function

    Public ReadOnly Property Unlocked() As Boolean Implements ILockingStrategy.Unlocked
        Get
            Return _unlocked
        End Get
    End Property

End Class
