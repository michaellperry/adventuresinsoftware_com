Public Class MyLockableObject _
    (Of LockingStrategy As {ILockingStrategy, New})

    Private _lockingStrategy As New LockingStrategy

    Public Sub BeginUse()
        _lockingStrategy.Lock()
    End Sub

    Public Sub EndUse()
        _lockingStrategy.Unlock()
    End Sub

End Class
